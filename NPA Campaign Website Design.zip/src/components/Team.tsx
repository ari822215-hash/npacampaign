const team = [
  {
    name: "Rania Putri",
    role: "Project Manager",
    bio: "Obsesi sama Notion dan deadline. Percaya bahwa hadir 100% bisa dipelajari.",
    avatar: "🧑‍💼",
    color: "#4D96FF",
    ig: "@rania.pm",
    in: "in/raniaputri",
  },
  {
    name: "Dimas Pratama",
    role: "Creative Director",
    bio: "Bikin visual yang bikin orang berhenti scroll — ironis, tapi intentional.",
    avatar: "🎨",
    color: "#FF6B6B",
    ig: "@dimas.crd",
    in: "in/dimaspratama",
  },
  {
    name: "Keisha Amara",
    role: "UI/UX Designer",
    bio: "Percaya bahwa desain yang baik adalah yang paling sedikit mengganggumu.",
    avatar: "✏️",
    color: "#6BCB77",
    ig: "@keisha.ux",
    in: "in/keishaamara",
  },
  {
    name: "Farhan Rizki",
    role: "Web Developer",
    bio: "Nulis kode sambil dengerin lofi. Hadir penuh — kecuali saat debugging.",
    avatar: "💻",
    color: "#FFD93D",
    ig: "@farhan.dev",
    in: "in/farhanrizki",
  },
  {
    name: "Nadia Sekar",
    role: "Research & Content",
    bio: "Suka riset, nulis, dan nanya 'tapi kenapa?' sampai ketemu jawaban yang jujur.",
    avatar: "📖",
    color: "#C4B5FD",
    ig: "@nadia.writes",
    in: "in/nadiasekar",
  },
  {
    name: "Bimo Aryanto",
    role: "Motion Designer",
    bio: "Animasi adalah bahasa. Dia lagi belajar ngomong lebih pelan.",
    avatar: "🎞️",
    color: "#FFB4A2",
    ig: "@bimo.motion",
    in: "in/bimoaryanto",
  },
];

export default function Team() {
  return (
    <section id="tim" className="section-pad" style={{ background: "#FFF8F0" }}>
      <div className="max-w-[1080px] mx-auto px-6">
        {/* Header */}
        <div className="text-center mb-4">
          <span className="kicker block mb-3">Tim NPA</span>
          <h2
            className="font-display font-800 mb-4"
            style={{ fontFamily: "'Baloo 2', cursive", fontWeight: 800, fontSize: "clamp(26px, 4vw, 38px)", color: "#1E2761", lineHeight: 1.2 }}
          >
            Di balik campaign ini.
          </h2>
        </div>

        <p
          className="text-center text-sm md:text-base leading-relaxed max-w-xl mx-auto mb-12 opacity-70"
          style={{ fontFamily: "'Plus Jakarta Sans', sans-serif", color: "#1E2761" }}
        >
          Dibuat oleh sekelompok manusia yang juga masih sering kelepasan buka HP — tapi percaya momen nyata lebih berharga.
        </p>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {team.map((member, i) => (
            <div
              key={i}
              className="neo-card p-5 group cursor-default transition-all duration-200 hover:-translate-y-1 hover:rotate-1"
              style={{ background: "#ffffff" }}
            >
              <div className="flex items-start gap-4">
                {/* Avatar */}
                <div
                  className="w-14 h-14 rounded-full neo-border flex items-center justify-center text-2xl flex-shrink-0"
                  style={{ background: member.color, borderColor: "#1E2761" }}
                >
                  {member.avatar}
                </div>
                <div className="flex-1 min-w-0">
                  <div
                    className="font-display font-800 text-base"
                    style={{ fontFamily: "'Baloo 2', cursive", fontWeight: 800, color: "#1E2761" }}
                  >
                    {member.name}
                  </div>
                  <div
                    className="text-xs font-700 mb-2"
                    style={{ fontFamily: "'Plus Jakarta Sans', sans-serif", fontWeight: 700, color: "#4D96FF" }}
                  >
                    {member.role}
                  </div>
                </div>
              </div>

              <p
                className="text-sm leading-relaxed mt-3 mb-3 opacity-75"
                style={{ fontFamily: "'Plus Jakarta Sans', sans-serif", color: "#1E2761" }}
              >
                {member.bio}
              </p>

              <div className="flex items-center gap-3">
                <span
                  className="text-xs font-700 px-2 py-1 rounded-full neo-border-2"
                  style={{
                    fontFamily: "'Plus Jakarta Sans', sans-serif",
                    fontWeight: 700,
                    background: "rgba(30,39,97,0.07)",
                    borderColor: "rgba(30,39,97,0.2)",
                    color: "#1E2761",
                    fontSize: "11px",
                  }}
                >
                  {member.ig}
                </span>
                <span
                  className="text-xs font-700 px-2 py-1 rounded-full neo-border-2"
                  style={{
                    fontFamily: "'Plus Jakarta Sans', sans-serif",
                    fontWeight: 700,
                    background: "rgba(30,39,97,0.07)",
                    borderColor: "rgba(30,39,97,0.2)",
                    color: "#1E2761",
                    fontSize: "11px",
                  }}
                >
                  {member.in}
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
