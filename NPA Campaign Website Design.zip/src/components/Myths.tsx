import { useState } from "react";

const myths = [
  {
    myth: "Kalau ada HP di meja, berarti kamu tetap bisa fokus asal ga dipegang.",
    fact: "Penelitian menunjukkan kehadiran HP—bahkan yang terbalik—sudah cukup mengurangi kapasitas kognitif kamu hingga 10%.",
    mythBg: "#FFD93D",
    factBg: "#4D96FF",
  },
  {
    myth: "Cek notif cepat itu ga ganggu percakapan.",
    fact: "Rata-rata butuh 23 menit untuk kembali fokus penuh setelah distraksi digital—bahkan yang 'cuma sebentar'.",
    mythBg: "#FFB4A2",
    factBg: "#6BCB77",
  },
  {
    myth: "Gen Z itu emang udah multitasking jadi HP bisa sambil ngobrol.",
    fact: "Tidak ada yang namanya multitasking — otak cuma task-switching. Setiap switch ada biaya konsentrasi yang dibayar.",
    mythBg: "#C4B5FD",
    factBg: "#FF6B6B",
  },
  {
    myth: "Kalau udah quality time, boleh dong sambil main HP sebentar.",
    fact: "Quality time yang terus-menerus tersela oleh HP sama seperti musik bagus yang diputus di tengah. Momennya ga pernah utuh.",
    mythBg: "#6BCB77",
    factBg: "#FFD93D",
  },
];

function MythCard({ myth, fact, mythBg, factBg }: (typeof myths)[0]) {
  const [flipped, setFlipped] = useState(false);

  return (
    <div
      className="flip-card cursor-pointer"
      style={{ height: 220 }}
      onClick={() => setFlipped(!flipped)}
    >
      <div className={`flip-card-inner ${flipped ? "flipped" : ""}`}>
        {/* Front — Mitos */}
        <div
          className="flip-card-front neo-card flex flex-col justify-between p-5"
          style={{ background: mythBg, height: 220 }}
        >
          <div
            className="inline-flex self-start px-3 py-1 text-xs font-800 rounded-full neo-border-2"
            style={{ fontFamily: "'Plus Jakarta Sans', sans-serif", fontWeight: 800, background: "rgba(255,255,255,0.5)", borderColor: "#1E2761", color: "#1E2761" }}
          >
            MITOS
          </div>
          <p
            className="font-display font-700 text-base leading-snug"
            style={{ fontFamily: "'Baloo 2', cursive", fontWeight: 700, color: "#1E2761" }}
          >
            "{myth}"
          </p>
          <div className="text-xs font-600 opacity-60 flex items-center gap-1" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif", color: "#1E2761" }}>
            tap untuk lihat faktanya →
          </div>
        </div>

        {/* Back — Fakta */}
        <div
          className="flip-card-back neo-card flex flex-col justify-between p-5"
          style={{ background: factBg, height: 220 }}
        >
          <div
            className="inline-flex self-start px-3 py-1 text-xs font-800 rounded-full neo-border-2"
            style={{
              fontFamily: "'Plus Jakarta Sans', sans-serif",
              fontWeight: 800,
              background: "rgba(255,255,255,0.5)",
              borderColor: "#1E2761",
              color: "#1E2761",
            }}
          >
            FAKTA
          </div>
          <p
            className="font-700 text-sm leading-relaxed"
            style={{ fontFamily: "'Plus Jakarta Sans', sans-serif", fontWeight: 700, color: "#1E2761" }}
          >
            {fact}
          </p>
          <div className="text-xs font-600 opacity-60 flex items-center gap-1" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif", color: "#1E2761" }}>
            ← tap untuk kembali
          </div>
        </div>
      </div>
    </div>
  );
}

export default function Myths() {
  return (
    <section className="section-pad" style={{ background: "#FFF8F0" }}>
      <div className="max-w-[1080px] mx-auto px-6">
        <div className="text-center mb-10">
          <span className="kicker block mb-3">Mitos vs Fakta</span>
          <h2
            className="font-display font-800 mb-3"
            style={{ fontFamily: "'Baloo 2', cursive", fontWeight: 800, fontSize: "clamp(26px, 4vw, 38px)", color: "#1E2761", lineHeight: 1.2 }}
          >
            Kamu yakin itu cuma mitos?
          </h2>
          <p className="text-sm opacity-60" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif", color: "#1E2761" }}>
            Tap kartu untuk balik ke fakta.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
          {myths.map((m, i) => (
            <MythCard key={i} {...m} />
          ))}
        </div>
      </div>
    </section>
  );
}
