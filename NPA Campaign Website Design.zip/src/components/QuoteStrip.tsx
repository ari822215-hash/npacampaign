import { useState } from "react";

const quotes = [
  { text: "Hadir sepenuhnya adalah hadiah terbaik yang bisa kamu berikan ke orang di depanmu.", author: "— Bukan notifikasi, bukan feed." },
  { text: "HP bisa ditaruh. Momen tidak bisa di-replay.", author: "— NPA Manifesto" },
  { text: "Kamu tidak perlu dokumentasi untuk membuktikan bahwa kamu bahagia.", author: "— Gen Z yang lagi healing" },
  { text: "Satu kontak mata lebih berharga dari seribu likes.", author: "— NPA Research 2024" },
  { text: "Orang yang paling kamu sayangi ada di depanmu. Bukan di layar itu.", author: "— Reminder harian" },
];

interface QuoteStripProps {
  position?: "top" | "bottom";
}

export default function QuoteStrip({ position = "top" }: QuoteStripProps) {
  const [current, setCurrent] = useState(0);

  const next = () => setCurrent((c) => (c + 1) % quotes.length);

  const topGrad = "linear-gradient(135deg, #FFD93D 0%, #FFB4A2 35%, #6BCB77 70%, #4D96FF 100%)";
  const botGrad = "linear-gradient(135deg, #4D96FF 0%, #6BCB77 35%, #FFB4A2 70%, #FFD93D 100%)";

  return (
    <div
      className="relative overflow-hidden cursor-pointer select-none group"
      style={{
        background: position === "top" ? topGrad : botGrad,
        border: "none",
        borderBottom: position === "top" ? "3px solid #1E2761" : "none",
        borderTop: position === "bottom" ? "3px solid #1E2761" : "none",
      }}
      onClick={next}
      role="button"
      tabIndex={0}
      onKeyDown={(e) => e.key === "Enter" && next()}
      aria-label="Next quote"
    >
      <div className="max-w-[1080px] mx-auto px-6 py-5 md:py-7">
        <div className="flex items-start gap-4">
          <div
            className="flex-shrink-0 text-xs font-700 tracking-wider uppercase py-1 px-3 rounded-full neo-border-2"
            style={{
              fontFamily: "'Plus Jakarta Sans', sans-serif",
              fontWeight: 700,
              background: "rgba(255,255,255,0.6)",
              color: "#1E2761",
              borderColor: "#1E2761",
              fontSize: "11px",
              letterSpacing: "0.08em",
            }}
          >
            Quote of the Moment
          </div>
          <div className="flex-1">
            <blockquote
              className="font-display font-700 text-lg md:text-xl leading-snug text-navy"
              style={{ fontFamily: "'Baloo 2', cursive", fontWeight: 700, color: "#1E2761", lineHeight: 1.3 }}
              key={current}
            >
              "{quotes[current].text}"
            </blockquote>
            <p
              className="mt-1 text-xs font-600 opacity-70"
              style={{ fontFamily: "'Plus Jakarta Sans', sans-serif", fontWeight: 600, color: "#1E2761" }}
            >
              {quotes[current].author}
            </p>
          </div>
          <div
            className="flex-shrink-0 hidden sm:flex items-center gap-1 text-xs font-700 opacity-60 group-hover:opacity-100 transition-opacity mt-1"
            style={{ fontFamily: "'Plus Jakarta Sans', sans-serif", color: "#1E2761" }}
          >
            klik untuk quote berikutnya →
          </div>
        </div>
      </div>
      {/* Progress dots */}
      <div className="absolute bottom-2 right-6 flex gap-1">
        {quotes.map((_, i) => (
          <div
            key={i}
            className="w-1.5 h-1.5 rounded-full transition-all"
            style={{ background: i === current ? "#1E2761" : "rgba(30,39,97,0.3)" }}
          />
        ))}
      </div>
    </div>
  );
}
