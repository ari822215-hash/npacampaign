const stats = [
  {
    value: "7 jam",
    label: "rata-rata orang Indonesia menatap layar per hari",
    bg: "#FFD93D",
    icon: "📱",
  },
  {
    value: "+40%",
    label: "penurunan empati saat ada HP di meja makan",
    bg: "#FF6B6B",
    icon: "💔",
  },
  {
    value: "2×",
    label: "lebih cepat kamu terdistraksi dibanding 10 tahun lalu",
    bg: "#6BCB77",
    icon: "🧠",
  },
  {
    value: "0",
    label: "percakapan bermakna yang dimulai sambil scroll",
    bg: "#4D96FF",
    icon: "💬",
  },
];

export default function Stats() {
  return (
    <section className="py-16" style={{ background: "#FFF8F0" }}>
      <div className="max-w-[1080px] mx-auto px-6">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-5">
          {stats.map((s, i) => (
            <div
              key={i}
              className="neo-card p-5 md:p-6 flex flex-col gap-2 hover:-translate-y-1 transition-transform duration-200"
              style={{ background: s.bg }}
            >
              <div className="text-2xl mb-1">{s.icon}</div>
              <div
                className="font-display font-800 leading-none"
                style={{ fontFamily: "'Baloo 2', cursive", fontWeight: 800, fontSize: "clamp(28px, 4vw, 42px)", color: "#1E2761" }}
              >
                {s.value}
              </div>
              <p
                className="text-xs font-600 leading-snug opacity-80"
                style={{ fontFamily: "'Plus Jakarta Sans', sans-serif", fontWeight: 600, color: "#1E2761" }}
              >
                {s.label}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
