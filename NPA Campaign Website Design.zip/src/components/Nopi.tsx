// Nopi — Gen Z mini humanoid mascot, not a blob
// Mint body + coral accents + navy outline, sassy expression

interface NopiProps {
  pose?: "idle" | "drop" | "crossed" | "point" | "win" | "sticker1" | "sticker2";
  size?: number;
  className?: string;
}

export default function Nopi({ pose = "idle", size = 120, className = "" }: NopiProps) {
  const scale = size / 140;

  const poses = {
    idle: (
      // Standing, phone in hand, flat expression
      <g>
        {/* Body - mint hoodie */}
        <rect x="42" y="64" width="56" height="58" rx="12" fill="#6BCB77" stroke="#1E2761" strokeWidth="3"/>
        {/* Hoodie pocket */}
        <rect x="52" y="86" width="36" height="18" rx="8" fill="rgba(30,39,97,0.12)" stroke="#1E2761" strokeWidth="2"/>
        {/* Legs */}
        <rect x="47" y="118" width="18" height="26" rx="8" fill="#1E2761"/>
        <rect x="75" y="118" width="18" height="26" rx="8" fill="#1E2761"/>
        {/* Shoes */}
        <ellipse cx="56" cy="144" rx="11" ry="6" fill="#FF6B6B" stroke="#1E2761" strokeWidth="2"/>
        <ellipse cx="84" cy="144" rx="11" ry="6" fill="#FF6B6B" stroke="#1E2761" strokeWidth="2"/>
        {/* Left arm - holding phone */}
        <rect x="14" y="68" width="30" height="14" rx="7" fill="#6BCB77" stroke="#1E2761" strokeWidth="3" transform="rotate(15 29 75)"/>
        {/* Phone */}
        <rect x="8" y="84" width="22" height="30" rx="5" fill="#1E2761" stroke="#1E2761" strokeWidth="2"/>
        <rect x="11" y="87" width="16" height="22" rx="3" fill="#4D96FF" opacity="0.8"/>
        <circle cx="19" cy="115" r="2" fill="#6BCB77"/>
        {/* Right arm */}
        <rect x="96" y="68" width="30" height="14" rx="7" fill="#6BCB77" stroke="#1E2761" strokeWidth="3" transform="rotate(-10 111 75)"/>
        {/* Head */}
        <ellipse cx="70" cy="42" rx="28" ry="28" fill="#FFB4A2" stroke="#1E2761" strokeWidth="3"/>
        {/* Hair */}
        <path d="M42 30 Q50 10 70 12 Q90 10 98 30 Q88 18 70 20 Q52 18 42 30Z" fill="#1E2761"/>
        {/* Eyes - flat/sassy */}
        <ellipse cx="60" cy="40" rx="5" ry="5.5" fill="#1E2761"/>
        <ellipse cx="80" cy="40" rx="5" ry="5.5" fill="#1E2761"/>
        {/* Eyebrow sassy - slightly raised */}
        <path d="M55 31 Q60 28 65 31" stroke="#1E2761" strokeWidth="2.5" fill="none" strokeLinecap="round"/>
        <path d="M75 29 Q80 27 86 30" stroke="#1E2761" strokeWidth="2.5" fill="none" strokeLinecap="round"/>
        {/* Mouth - flat line */}
        <path d="M63 52 Q70 54 77 52" stroke="#1E2761" strokeWidth="2" fill="none" strokeLinecap="round"/>
        {/* Hoodie hood detail */}
        <path d="M42 64 Q70 56 98 64" stroke="#1E2761" strokeWidth="2" fill="none"/>
      </g>
    ),

    drop: (
      // Phone being dropped/dismissed, looking forward confidently
      <g>
        {/* Body */}
        <rect x="42" y="64" width="56" height="58" rx="12" fill="#6BCB77" stroke="#1E2761" strokeWidth="3"/>
        <rect x="52" y="86" width="36" height="18" rx="8" fill="rgba(30,39,97,0.12)" stroke="#1E2761" strokeWidth="2"/>
        {/* Legs */}
        <rect x="47" y="118" width="18" height="26" rx="8" fill="#1E2761"/>
        <rect x="75" y="118" width="18" height="26" rx="8" fill="#1E2761"/>
        <ellipse cx="56" cy="144" rx="11" ry="6" fill="#FF6B6B" stroke="#1E2761" strokeWidth="2"/>
        <ellipse cx="84" cy="144" rx="11" ry="6" fill="#FF6B6B" stroke="#1E2761" strokeWidth="2"/>
        {/* Left arm - releasing/waving off */}
        <rect x="10" y="72" width="34" height="14" rx="7" fill="#6BCB77" stroke="#1E2761" strokeWidth="3" transform="rotate(-30 27 79)"/>
        {/* Phone falling with motion lines */}
        <rect x="5" y="98" width="18" height="26" rx="4" fill="#1E2761" transform="rotate(25 14 111)"/>
        <rect x="8" y="101" width="12" height="18" rx="2" fill="#4D96FF" opacity="0.6" transform="rotate(25 14 111)"/>
        {/* Motion lines */}
        <line x1="20" y1="95" x2="15" y2="105" stroke="#1E2761" strokeWidth="2" strokeDasharray="3,2"/>
        <line x1="14" y1="93" x2="10" y2="103" stroke="#1E2761" strokeWidth="1.5" strokeDasharray="3,2"/>
        {/* Right arm - slight out */}
        <rect x="96" y="72" width="30" height="14" rx="7" fill="#6BCB77" stroke="#1E2761" strokeWidth="3" transform="rotate(20 111 79)"/>
        {/* Head */}
        <ellipse cx="70" cy="42" rx="28" ry="28" fill="#FFB4A2" stroke="#1E2761" strokeWidth="3"/>
        <path d="M42 30 Q50 10 70 12 Q90 10 98 30 Q88 18 70 20 Q52 18 42 30Z" fill="#1E2761"/>
        {/* Eyes - confident, looking forward */}
        <ellipse cx="60" cy="40" rx="5.5" ry="6" fill="#1E2761"/>
        <ellipse cx="80" cy="40" rx="5.5" ry="6" fill="#1E2761"/>
        {/* Eye shine */}
        <circle cx="62" cy="38" r="1.5" fill="white"/>
        <circle cx="82" cy="38" r="1.5" fill="white"/>
        {/* Eyebrows - determined */}
        <path d="M54 30 Q60 26 66 29" stroke="#1E2761" strokeWidth="2.5" fill="none" strokeLinecap="round"/>
        <path d="M74 29 Q80 26 86 29" stroke="#1E2761" strokeWidth="2.5" fill="none" strokeLinecap="round"/>
        {/* Small smile */}
        <path d="M63 52 Q70 57 77 52" stroke="#1E2761" strokeWidth="2" fill="none" strokeLinecap="round"/>
        <path d="M42 64 Q70 56 98 64" stroke="#1E2761" strokeWidth="2" fill="none"/>
      </g>
    ),

    crossed: (
      // Arms crossed, slightly serious/stern
      <g>
        <rect x="42" y="64" width="56" height="58" rx="12" fill="#6BCB77" stroke="#1E2761" strokeWidth="3"/>
        <rect x="52" y="86" width="36" height="18" rx="8" fill="rgba(30,39,97,0.12)" stroke="#1E2761" strokeWidth="2"/>
        <rect x="47" y="118" width="18" height="26" rx="8" fill="#1E2761"/>
        <rect x="75" y="118" width="18" height="26" rx="8" fill="#1E2761"/>
        <ellipse cx="56" cy="144" rx="11" ry="6" fill="#FF6B6B" stroke="#1E2761" strokeWidth="2"/>
        <ellipse cx="84" cy="144" rx="11" ry="6" fill="#FF6B6B" stroke="#1E2761" strokeWidth="2"/>
        {/* Arms crossed */}
        <path d="M14 80 Q35 90 70 86 Q105 90 126 80" stroke="#6BCB77" strokeWidth="14" fill="none" strokeLinecap="round" strokeLinejoin="round"/>
        <path d="M14 80 Q35 90 70 86 Q105 90 126 80" stroke="#1E2761" strokeWidth="3" fill="none" strokeLinecap="round" strokeLinejoin="round"/>
        {/* Head */}
        <ellipse cx="70" cy="42" rx="28" ry="28" fill="#FFB4A2" stroke="#1E2761" strokeWidth="3"/>
        <path d="M42 30 Q50 10 70 12 Q90 10 98 30 Q88 18 70 20 Q52 18 42 30Z" fill="#1E2761"/>
        {/* Eyes - skeptical, one slightly narrowed */}
        <ellipse cx="60" cy="40" rx="5" ry="4.5" fill="#1E2761"/>
        <ellipse cx="80" cy="40" rx="5" ry="5.5" fill="#1E2761"/>
        {/* Eyebrow - one raised, one flat */}
        <path d="M54 30 Q60 26 66 28" stroke="#1E2761" strokeWidth="2.5" fill="none" strokeLinecap="round"/>
        <path d="M74 32 Q80 30 86 32" stroke="#1E2761" strokeWidth="2.5" fill="none" strokeLinecap="round"/>
        {/* Flat mouth */}
        <path d="M64 52 L76 52" stroke="#1E2761" strokeWidth="2.5" fill="none" strokeLinecap="round"/>
        <path d="M42 64 Q70 56 98 64" stroke="#1E2761" strokeWidth="2" fill="none"/>
      </g>
    ),

    point: (
      // Pointing at CTA, slight lean
      <g>
        <rect x="42" y="64" width="56" height="62" rx="12" fill="#6BCB77" stroke="#1E2761" strokeWidth="3"/>
        <rect x="52" y="88" width="36" height="18" rx="8" fill="rgba(30,39,97,0.12)" stroke="#1E2761" strokeWidth="2"/>
        <rect x="47" y="122" width="18" height="24" rx="8" fill="#1E2761"/>
        <rect x="75" y="122" width="18" height="24" rx="8" fill="#1E2761"/>
        <ellipse cx="56" cy="146" rx="11" ry="6" fill="#FF6B6B" stroke="#1E2761" strokeWidth="2"/>
        <ellipse cx="84" cy="146" rx="11" ry="6" fill="#FF6B6B" stroke="#1E2761" strokeWidth="2"/>
        {/* Right arm pointing right */}
        <path d="M98 76 Q115 70 132 62" stroke="#6BCB77" strokeWidth="14" fill="none" strokeLinecap="round"/>
        <path d="M98 76 Q115 70 132 62" stroke="#1E2761" strokeWidth="3" fill="none" strokeLinecap="round"/>
        {/* Pointing finger */}
        <ellipse cx="136" cy="60" rx="7" ry="5" fill="#FFB4A2" stroke="#1E2761" strokeWidth="2.5" transform="rotate(-15 136 60)"/>
        {/* Left arm down */}
        <rect x="10" y="76" width="34" height="14" rx="7" fill="#6BCB77" stroke="#1E2761" strokeWidth="3" transform="rotate(10 27 83)"/>
        {/* Head */}
        <ellipse cx="70" cy="42" rx="28" ry="28" fill="#FFB4A2" stroke="#1E2761" strokeWidth="3"/>
        <path d="M42 30 Q50 10 70 12 Q90 10 98 30 Q88 18 70 20 Q52 18 42 30Z" fill="#1E2761"/>
        <ellipse cx="60" cy="40" rx="5.5" ry="6" fill="#1E2761"/>
        <ellipse cx="80" cy="40" rx="5.5" ry="6" fill="#1E2761"/>
        <circle cx="62" cy="38" r="1.5" fill="white"/>
        <circle cx="82" cy="38" r="1.5" fill="white"/>
        <path d="M54 30 Q60 27 66 30" stroke="#1E2761" strokeWidth="2.5" fill="none" strokeLinecap="round"/>
        <path d="M74 29 Q80 26 86 29" stroke="#1E2761" strokeWidth="2.5" fill="none" strokeLinecap="round"/>
        <path d="M63 52 Q70 55 77 52" stroke="#1E2761" strokeWidth="2" fill="none" strokeLinecap="round"/>
        <path d="M42 64 Q70 56 98 64" stroke="#1E2761" strokeWidth="2" fill="none"/>
      </g>
    ),

    win: (
      // Small win — subtle nod/smile, slight fist pump
      <g>
        <rect x="42" y="64" width="56" height="58" rx="12" fill="#6BCB77" stroke="#1E2761" strokeWidth="3"/>
        <rect x="52" y="86" width="36" height="18" rx="8" fill="rgba(30,39,97,0.12)" stroke="#1E2761" strokeWidth="2"/>
        <rect x="47" y="118" width="18" height="26" rx="8" fill="#1E2761"/>
        <rect x="75" y="118" width="18" height="26" rx="8" fill="#1E2761"/>
        <ellipse cx="56" cy="144" rx="11" ry="6" fill="#FF6B6B" stroke="#1E2761" strokeWidth="2"/>
        <ellipse cx="84" cy="144" rx="11" ry="6" fill="#FF6B6B" stroke="#1E2761" strokeWidth="2"/>
        {/* Right arm raised slightly */}
        <path d="M98 72 Q112 55 116 42" stroke="#6BCB77" strokeWidth="14" fill="none" strokeLinecap="round"/>
        <path d="M98 72 Q112 55 116 42" stroke="#1E2761" strokeWidth="3" fill="none" strokeLinecap="round"/>
        {/* Fist */}
        <rect x="110" y="32" width="18" height="14" rx="6" fill="#FFB4A2" stroke="#1E2761" strokeWidth="2.5"/>
        {/* Left arm relaxed */}
        <rect x="10" y="74" width="34" height="14" rx="7" fill="#6BCB77" stroke="#1E2761" strokeWidth="3" transform="rotate(5 27 81)"/>
        {/* Head */}
        <ellipse cx="70" cy="40" rx="28" ry="28" fill="#FFB4A2" stroke="#1E2761" strokeWidth="3"/>
        <path d="M42 28 Q50 8 70 10 Q90 8 98 28 Q88 16 70 18 Q52 16 42 28Z" fill="#1E2761"/>
        {/* Eyes - happy squint */}
        <path d="M54 38 Q60 33 66 38" stroke="#1E2761" strokeWidth="3" fill="none" strokeLinecap="round"/>
        <path d="M74 38 Q80 33 86 38" stroke="#1E2761" strokeWidth="3" fill="none" strokeLinecap="round"/>
        {/* Eyebrows up */}
        <path d="M53 28 Q60 24 66 27" stroke="#1E2761" strokeWidth="2.5" fill="none" strokeLinecap="round"/>
        <path d="M74 27 Q80 24 87 27" stroke="#1E2761" strokeWidth="2.5" fill="none" strokeLinecap="round"/>
        {/* Smile */}
        <path d="M61 50 Q70 57 79 50" stroke="#1E2761" strokeWidth="2.5" fill="none" strokeLinecap="round"/>
        {/* Cheek dots */}
        <circle cx="54" cy="46" r="4" fill="#FF6B6B" opacity="0.3"/>
        <circle cx="86" cy="46" r="4" fill="#FF6B6B" opacity="0.3"/>
        <path d="M42 62 Q70 54 98 62" stroke="#1E2761" strokeWidth="2" fill="none"/>
        {/* Stars */}
        <text x="18" y="30" fontSize="14" fill="#FFD93D">✦</text>
        <text x="118" y="26" fontSize="12" fill="#FFD93D">✦</text>
      </g>
    ),

    sticker1: (
      // Eyeroll / "really?" reaction
      <g>
        <ellipse cx="70" cy="50" rx="44" ry="44" fill="#6BCB77" stroke="#1E2761" strokeWidth="3"/>
        {/* Face */}
        <ellipse cx="70" cy="52" rx="28" ry="28" fill="#FFB4A2" stroke="#1E2761" strokeWidth="2.5"/>
        {/* Eyes rolled up */}
        <ellipse cx="60" cy="50" rx="5" ry="5.5" fill="#1E2761"/>
        <ellipse cx="80" cy="50" rx="5" ry="5.5" fill="#1E2761"/>
        <ellipse cx="60" cy="47" rx="3" ry="3" fill="white"/>
        <ellipse cx="80" cy="47" rx="3" ry="3" fill="white"/>
        {/* Eyebrows up exasperated */}
        <path d="M54 38 Q60 34 66 37" stroke="#1E2761" strokeWidth="2.5" fill="none" strokeLinecap="round"/>
        <path d="M74 37 Q80 34 86 37" stroke="#1E2761" strokeWidth="2.5" fill="none" strokeLinecap="round"/>
        {/* Flat unimpressed mouth */}
        <path d="M62 64 L78 64" stroke="#1E2761" strokeWidth="2.5" fill="none" strokeLinecap="round"/>
        {/* Text */}
        <text x="70" y="105" textAnchor="middle" fontFamily="'Plus Jakarta Sans'" fontWeight="800" fontSize="11" fill="#1E2761">serius deh...</text>
      </g>
    ),

    sticker2: (
      // Thumbs up but small/cool
      <g>
        <ellipse cx="70" cy="55" rx="48" ry="48" fill="#FFD93D" stroke="#1E2761" strokeWidth="3"/>
        <ellipse cx="70" cy="50" rx="24" ry="24" fill="#FFB4A2" stroke="#1E2761" strokeWidth="2.5"/>
        {/* Cool eyes */}
        <path d="M55 48 Q60 43 65 48" stroke="#1E2761" strokeWidth="3" fill="none" strokeLinecap="round"/>
        <path d="M75 48 Q80 43 85 48" stroke="#1E2761" strokeWidth="3" fill="none" strokeLinecap="round"/>
        <path d="M54 38 Q60 35 65 38" stroke="#1E2761" strokeWidth="2" fill="none" strokeLinecap="round"/>
        <path d="M75 38 Q80 35 85 38" stroke="#1E2761" strokeWidth="2" fill="none" strokeLinecap="round"/>
        {/* Smirk */}
        <path d="M64 60 Q73 65 78 60" stroke="#1E2761" strokeWidth="2.5" fill="none" strokeLinecap="round"/>
        {/* Thumbs up */}
        <path d="M28 72 Q32 58 38 55 L44 55 L44 80 L28 80 Z" fill="#FFB4A2" stroke="#1E2761" strokeWidth="2.5"/>
        <path d="M44 60 Q50 50 56 55 Q62 50 68 52 Q74 50 74 57 Q74 64 44 64" fill="#FFB4A2" stroke="#1E2761" strokeWidth="2.5"/>
        <text x="70" y="110" textAnchor="middle" fontFamily="'Plus Jakarta Sans'" fontWeight="800" fontSize="11" fill="#1E2761">oke, good!</text>
      </g>
    ),
  };

  return (
    <svg
      viewBox="0 0 140 155"
      width={size}
      height={size * (155 / 140)}
      className={className}
      style={{ overflow: "visible" }}
    >
      {poses[pose]}
    </svg>
  );
}
