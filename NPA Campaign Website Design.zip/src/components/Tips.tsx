const tips = [
  {
    icon: "🍽️",
    title: "No Phone Meal",
    desc: "HP masuk saku atau tas saat makan. Bukan silent, bukan face-down. Betul-betul tidak ada.",
    bg: "#FFD93D",
  },
  {
    icon: "🌅",
    title: "First 30 Minutes",
    desc: "Tiga puluh menit pertama setelah bangun — tanpa scroll. Mulai hari dengan otakmu sendiri.",
    bg: "#FFB4A2",
  },
  {
    icon: "🚶",
    title: "Walk & Talk",
    desc: "Jalan bareng orang yang kamu care tanpa earphone dan tanpa HP. Percakapan terbaik sering lahir dari sini.",
    bg: "#6BCB77",
  },
  {
    icon: "📦",
    title: "Phone Parking",
    desc: "Satu tempat di rumah untuk 'parkir' HP saat kumpul. Laci, box kecil, luar ruangan — pilih tempatmu.",
    bg: "#4D96FF",
  },
];

export default function Tips() {
  return (
    <section className="section-pad" style={{ background: "#1E2761" }}>
      <div className="max-w-[1080px] mx-auto px-6">
        <div className="text-center mb-10">
          <span className="kicker block mb-3" style={{ color: "#6BCB77" }}>Kebiasaan kecil</span>
          <h2
            className="font-display font-800 mb-3"
            style={{ fontFamily: "'Baloo 2', cursive", fontWeight: 800, fontSize: "clamp(26px, 4vw, 38px)", color: "#FFF8F0", lineHeight: 1.2 }}
          >
            4 kebiasaan yang mulai bisa kamu coba hari ini
          </h2>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
          {tips.map((tip, i) => (
            <div
              key={i}
              className="neo-card p-6 flex flex-col gap-3 hover:-translate-y-1.5 transition-transform duration-200 cursor-default"
              style={{ background: tip.bg }}
            >
              <div className="text-3xl">{tip.icon}</div>
              <h3
                className="font-display font-700 text-lg leading-tight"
                style={{ fontFamily: "'Baloo 2', cursive", fontWeight: 700, color: "#1E2761" }}
              >
                {tip.title}
              </h3>
              <p
                className="text-sm leading-relaxed flex-1"
                style={{ fontFamily: "'Plus Jakarta Sans', sans-serif", color: "#1E2761", opacity: 0.8 }}
              >
                {tip.desc}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
