export default function Footer() {
  const links = [
    { label: "Kenapa NPA", href: "#edukasi" },
    { label: "Tes", href: "#doomtest" },
    { label: "Challenge", href: "#challenge" },
    { label: "Game", href: "#game" },
    { label: "Tim", href: "#tim" },
  ];

  const sources = [
    "We Are Social Digital Report 2024",
    "DataReportal Indonesia",
    "Ward & Wegner (2017) — Brain Drain Study",
    "American Psychological Association, Attention Research",
  ];

  return (
    <footer style={{ background: "#1E2761" }}>
      <div className="max-w-[1080px] mx-auto px-6 py-14">
        {/* Top row */}
        <div className="flex flex-col md:flex-row justify-between gap-10 mb-12">
          {/* Brand */}
          <div className="max-w-xs">
            <div className="flex items-center gap-2 mb-4">
              <div
                className="w-10 h-10 rounded-full flex items-center justify-center font-display font-800 text-lg"
                style={{ background: "#FFF8F0", color: "#1E2761", fontFamily: "'Baloo 2', cursive", fontWeight: 800, border: "3px solid rgba(255,255,255,0.3)" }}
              >
                N
              </div>
              <span
                className="font-display font-800 text-xl text-cream"
                style={{ fontFamily: "'Baloo 2', cursive", fontWeight: 800, color: "#FFF8F0" }}
              >
                NPA
                <span className="inline-block w-2 h-2 rounded-full ml-0.5 mb-1 align-middle" style={{ background: "#6BCB77" }} />
              </span>
            </div>
            <p
              className="text-sm leading-relaxed opacity-60"
              style={{ fontFamily: "'Plus Jakarta Sans', sans-serif", color: "#FFF8F0" }}
            >
              Less Screen, More Connection.
            </p>
            <p
              className="text-xs italic leading-relaxed opacity-40 mt-2"
              style={{ fontFamily: "'Plus Jakarta Sans', sans-serif", color: "#FFF8F0" }}
            >
              "Put the phone down. Pick the moment up."
            </p>
          </div>

          {/* Nav */}
          <div>
            <div
              className="text-xs font-800 uppercase tracking-wider mb-4 opacity-50"
              style={{ fontFamily: "'Plus Jakarta Sans', sans-serif", color: "#FFF8F0" }}
            >
              Navigasi
            </div>
            <ul className="flex flex-col gap-2.5">
              {links.map((l) => (
                <li key={l.href}>
                  <a
                    href={l.href}
                    className="text-sm font-600 opacity-70 hover:opacity-100 transition-opacity"
                    style={{ fontFamily: "'Plus Jakarta Sans', sans-serif", fontWeight: 600, color: "#FFF8F0" }}
                  >
                    {l.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Sources */}
          <div className="max-w-xs">
            <div
              className="text-xs font-800 uppercase tracking-wider mb-4 opacity-50"
              style={{ fontFamily: "'Plus Jakarta Sans', sans-serif", color: "#FFF8F0" }}
            >
              Sumber Data
            </div>
            <ul className="flex flex-col gap-2">
              {sources.map((s, i) => (
                <li
                  key={i}
                  className="text-xs opacity-40"
                  style={{ fontFamily: "'Plus Jakarta Sans', sans-serif", color: "#FFF8F0" }}
                >
                  {s}
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* Divider */}
        <div style={{ borderTop: "1px solid rgba(255,255,255,0.12)", paddingTop: 24 }}>
          {/* Disclaimer */}
          <div
            className="neo-card p-4 mb-6"
            style={{ background: "rgba(255,255,255,0.08)", borderColor: "rgba(255,255,255,0.2)" }}
          >
            <p
              className="text-xs leading-relaxed opacity-70 text-center"
              style={{ fontFamily: "'Plus Jakarta Sans', sans-serif", color: "#FFF8F0" }}
            >
              <strong style={{ fontWeight: 700 }}>Kampanye edukasi.</strong> Bukan anti-teknologi.{" "}
              Yang dilawan adalah ketiadaan kehadiran.
            </p>
          </div>

          {/* Copyright */}
          <div className="flex flex-col md:flex-row items-center justify-between gap-3">
            <p
              className="text-xs opacity-30 text-center"
              style={{ fontFamily: "'Plus Jakarta Sans', sans-serif", color: "#FFF8F0" }}
            >
              © 2024 NPA — No Phones Around. Dibuat dengan ❤️ dan sedikit gangguan HP.
            </p>
            <a
              href="#"
              className="text-xs font-700 px-3 py-1.5 rounded-full transition-all hover:opacity-100 opacity-50"
              style={{
                fontFamily: "'Plus Jakarta Sans', sans-serif",
                background: "rgba(255,255,255,0.1)",
                color: "#FFF8F0",
                fontWeight: 700,
              }}
            >
              ↑ Kembali ke atas
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
}
