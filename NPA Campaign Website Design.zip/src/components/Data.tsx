import { useState, useEffect } from "react";

const dataPoints = [
  { year: "2015", hours: 3.2 },
  { year: "2017", hours: 4.1 },
  { year: "2019", hours: 5.3 },
  { year: "2021", hours: 6.4 },
  { year: "2023", hours: 6.9 },
  { year: "2024", hours: 7.2 },
];

export default function Data() {
  const [counter, setCounter] = useState(12847);

  useEffect(() => {
    const interval = setInterval(() => {
      setCounter((c) => c + Math.floor(Math.random() * 3) + 1);
    }, 1800);
    return () => clearInterval(interval);
  }, []);

  const maxH = Math.max(...dataPoints.map((d) => d.hours));

  return (
    <section className="section-pad" style={{ background: "#1E2761" }}>
      <div className="max-w-[1080px] mx-auto px-6">
        <div className="text-center mb-10">
          <span className="kicker block mb-3" style={{ color: "#FFD93D" }}>Data yang bicara</span>
          <h2
            className="font-display font-800 mb-2"
            style={{ fontFamily: "'Baloo 2', cursive", fontWeight: 800, fontSize: "clamp(26px, 4vw, 38px)", color: "#FFF8F0", lineHeight: 1.2 }}
          >
            Rata-rata screen time Indonesia
          </h2>
          <p className="text-sm opacity-50" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif", color: "#FFF8F0" }}>
            Sumber: We Are Social, DataReportal, Statista (2024)
          </p>
        </div>

        {/* Chart */}
        <div
          className="neo-card p-6 md:p-8 mb-8"
          style={{ background: "#FFF8F0" }}
        >
          <div className="flex items-end gap-3 md:gap-5 h-44 mb-2">
            {dataPoints.map((d, i) => (
              <div key={d.year} className="flex-1 flex flex-col items-center gap-1">
                <div
                  className="font-display font-800 text-xs text-center"
                  style={{ fontFamily: "'Baloo 2', cursive", color: "#1E2761" }}
                >
                  {d.hours}h
                </div>
                <div
                  className="w-full rounded-t-lg neo-border transition-all duration-700"
                  style={{
                    height: `${(d.hours / maxH) * 140}px`,
                    background: [
                      "#4D96FF", "#6BCB77", "#FFD93D", "#FFB4A2", "#FF6B6B", "#C4B5FD"
                    ][i],
                    borderColor: "#1E2761",
                    animationDelay: `${i * 100}ms`,
                  }}
                />
                <div
                  className="text-xs font-700 text-center"
                  style={{ fontFamily: "'Plus Jakarta Sans', sans-serif", color: "#1E2761", fontWeight: 700 }}
                >
                  {d.year}
                </div>
              </div>
            ))}
          </div>
          <div className="text-xs opacity-60 text-center" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif", color: "#1E2761" }}>
            Jam per hari rata-rata orang Indonesia
          </div>
        </div>

        {/* Live counter */}
        <div
          className="neo-card p-6 text-center"
          style={{ background: "#FFD93D" }}
        >
          <p className="text-sm font-700 mb-2" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif", color: "#1E2761", fontWeight: 700 }}>
            Orang sedang NPA mode hari ini 🌱
          </p>
          <div
            className="font-display font-800"
            style={{ fontFamily: "'Baloo 2', cursive", fontWeight: 800, fontSize: "clamp(36px, 5vw, 56px)", color: "#1E2761" }}
          >
            {counter.toLocaleString("id-ID")}
          </div>
          <p className="text-xs opacity-60 mt-1" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif", color: "#1E2761" }}>
            dan bertambah setiap detiknya
          </p>
        </div>
      </div>
    </section>
  );
}
