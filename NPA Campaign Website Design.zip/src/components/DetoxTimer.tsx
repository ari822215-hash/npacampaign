import { useState, useEffect, useRef } from "react";

const STAGES = [
  { threshold: 0, emoji: "🌱", label: "Mulai", desc: "Taruh HP, tarik nafas." },
  { threshold: 60, emoji: "🌿", label: "Berkembang", desc: "Sudah 1 menit. Teruskan." },
  { threshold: 300, emoji: "🌳", label: "Tumbuh", desc: "5 menit! Kamu lagi hadir." },
  { threshold: 900, emoji: "🌳🐦", label: "Hidup", desc: "15 menit bebas layar. Luar biasa." },
  { threshold: 1800, emoji: "🧑‍🤝‍🧑", label: "Terhubung", desc: "Setengah jam. Koneksi nyata dimulai." },
  { threshold: 3600, emoji: "☀️", label: "NPA Mode", desc: "Satu jam! Kamu legend." },
];

export default function DetoxTimer() {
  const [running, setRunning] = useState(false);
  const [seconds, setSeconds] = useState(0);
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const start = () => {
    setRunning(true);
    setSeconds(0);
    timerRef.current = setInterval(() => setSeconds((s) => s + 1), 1000);
  };

  const stop = () => {
    setRunning(false);
    if (timerRef.current) clearInterval(timerRef.current);
  };

  const reset = () => {
    stop();
    setSeconds(0);
  };

  useEffect(() => {
    return () => { if (timerRef.current) clearInterval(timerRef.current); };
  }, []);

  const stage = STAGES.reduce((acc, s) => (seconds >= s.threshold ? s : acc), STAGES[0]);
  const nextStage = STAGES.find((s) => s.threshold > seconds);
  const progress = nextStage
    ? Math.min(100, ((seconds - stage.threshold) / (nextStage.threshold - stage.threshold)) * 100)
    : 100;

  const fmt = (s: number) => {
    const m = Math.floor(s / 60);
    const sec = s % 60;
    return `${m.toString().padStart(2, "0")}:${sec.toString().padStart(2, "0")}`;
  };

  return (
    <section className="section-pad" style={{ background: "#FFF8F0" }}>
      <div className="max-w-[1080px] mx-auto px-6">
        <div className="text-center mb-10">
          <span className="kicker block mb-3">Digital Detox Timer</span>
          <h2
            className="font-display font-800 mb-3"
            style={{ fontFamily: "'Baloo 2', cursive", fontWeight: 800, fontSize: "clamp(26px, 4vw, 38px)", color: "#1E2761", lineHeight: 1.2 }}
          >
            Taruh HP. Mulai timer.
          </h2>
          <p className="text-sm opacity-70" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif", color: "#1E2761" }}>
            Lihat hidupmu tumbuh seiring waktu.
          </p>
        </div>

        <div className="max-w-sm mx-auto">
          <div className="neo-card p-8 text-center" style={{ background: "#FFF8F0" }}>
            {/* Stage emoji */}
            <div
              className="text-6xl mb-4 leading-none"
              style={{ transition: "all 0.5s ease" }}
            >
              {stage.emoji}
            </div>

            {/* Timer display */}
            <div
              className="font-display font-800 mb-2"
              style={{
                fontFamily: "'Baloo 2', cursive",
                fontWeight: 800,
                fontSize: "clamp(52px, 10vw, 80px)",
                color: "#1E2761",
                lineHeight: 1,
              }}
            >
              {fmt(seconds)}
            </div>

            {/* Stage label */}
            <div
              className="font-700 text-base mb-1"
              style={{ fontFamily: "'Plus Jakarta Sans', sans-serif", fontWeight: 700, color: "#1E2761" }}
            >
              {stage.label}
            </div>
            <p className="text-sm opacity-60 mb-6" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif", color: "#1E2761" }}>
              {stage.desc}
            </p>

            {/* Progress to next stage */}
            {nextStage && (
              <div className="mb-6">
                <div className="flex justify-between text-xs font-600 mb-1.5 opacity-60" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif", color: "#1E2761" }}>
                  <span>menuju {nextStage.label}</span>
                  <span>{Math.round(progress)}%</span>
                </div>
                <div className="h-3 rounded-full neo-border overflow-hidden" style={{ borderColor: "#1E2761" }}>
                  <div className="progress-bar-fill h-full" style={{ width: `${progress}%` }} />
                </div>
              </div>
            )}

            {/* Stage milestones */}
            <div className="flex justify-between mb-6">
              {STAGES.map((s, i) => (
                <div
                  key={i}
                  className="flex flex-col items-center gap-0.5"
                  style={{ opacity: seconds >= s.threshold ? 1 : 0.3, transition: "opacity 0.5s" }}
                >
                  <span style={{ fontSize: 18 }}>{s.emoji.split("")[0]}</span>
                  <span className="text-[9px] font-700" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif", color: "#1E2761" }}>
                    {s.threshold >= 60 ? `${Math.floor(s.threshold / 60)}m` : "0"}
                  </span>
                </div>
              ))}
            </div>

            {/* Controls */}
            <div className="flex gap-3">
              {!running ? (
                <button className="btn-neo btn-coral flex-1 justify-center" onClick={start}>
                  ▶ Mulai
                </button>
              ) : (
                <button className="btn-neo btn-navy flex-1 justify-center" onClick={stop}>
                  ⏸ Pause
                </button>
              )}
              <button className="btn-neo btn-outline" onClick={reset} style={{ color: "#1E2761" }}>
                ↺
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
