import { useState, useEffect, useRef, useCallback } from "react";

interface Bubble {
  id: number;
  x: number;
  speed: number;
  emoji: string;
  color: string;
  y: number;
  caught: boolean;
}

const BUBBLES_EMOJIS = ["📱", "🔔", "❤️", "💬", "👍", "📲", "🔁", "⚡"];
const BUBBLE_COLORS = ["#FF6B6B", "#FFD93D", "#4D96FF", "#C4B5FD", "#FFB4A2", "#6BCB77"];

type GamePhase = "idle" | "playing" | "result";

export default function MiniGame() {
  const [phase, setPhase] = useState<GamePhase>("idle");
  const [score, setScore] = useState(0);
  const [timeLeft, setTimeLeft] = useState(20);
  const [bubbles, setBubbles] = useState<Bubble[]>([]);
  const [missed, setMissed] = useState(0);
  const nextId = useRef(0);
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const spawnRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const spawnBubble = useCallback(() => {
    const id = nextId.current++;
    setBubbles((bs) => [
      ...bs,
      {
        id,
        x: 10 + Math.random() * 70,
        speed: 4 + Math.random() * 3,
        emoji: BUBBLES_EMOJIS[Math.floor(Math.random() * BUBBLES_EMOJIS.length)],
        color: BUBBLE_COLORS[Math.floor(Math.random() * BUBBLE_COLORS.length)],
        y: -10,
        caught: false,
      },
    ]);
  }, []);

  useEffect(() => {
    if (phase !== "playing") return;

    timerRef.current = setInterval(() => {
      setTimeLeft((t) => {
        if (t <= 1) {
          if (timerRef.current) clearInterval(timerRef.current);
          if (spawnRef.current) clearInterval(spawnRef.current);
          setPhase("result");
          return 0;
        }
        return t - 1;
      });
    }, 1000);

    spawnRef.current = setInterval(spawnBubble, 800);

    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
      if (spawnRef.current) clearInterval(spawnRef.current);
    };
  }, [phase, spawnBubble]);

  // Move bubbles down
  useEffect(() => {
    if (phase !== "playing") return;
    const animFrame = requestAnimationFrame(function loop() {
      setBubbles((bs) =>
        bs
          .map((b) => ({ ...b, y: b.y + b.speed * 0.4 }))
          .filter((b) => {
            if (b.y > 110 && !b.caught) {
              setMissed((m) => m + 1);
              return false;
            }
            if (b.caught) return false;
            return true;
          })
      );
      if (phase === "playing") requestAnimationFrame(loop);
    });
    return () => cancelAnimationFrame(animFrame);
  }, [phase]);

  const catchBubble = (id: number) => {
    setBubbles((bs) => bs.map((b) => (b.id === id ? { ...b, caught: true } : b)));
    setScore((s) => s + 10);
  };

  const startGame = () => {
    setPhase("playing");
    setScore(0);
    setTimeLeft(20);
    setMissed(0);
    setBubbles([]);
  };

  const rating =
    score >= 150 ? "🏆 Pro Blocker!" : score >= 80 ? "👍 Lumayan jago!" : "💪 Bisa lebih baik!";

  return (
    <section id="game" className="section-pad" style={{ background: "#FFF8F0" }}>
      <div className="max-w-[1080px] mx-auto px-6">
        <div className="text-center mb-10">
          <span className="kicker block mb-3">Mini Game</span>
          <h2
            className="font-display font-800 mb-3"
            style={{ fontFamily: "'Baloo 2', cursive", fontWeight: 800, fontSize: "clamp(26px, 4vw, 38px)", color: "#1E2761", lineHeight: 1.2 }}
          >
            Save the Conversation!
          </h2>
          <p className="text-sm opacity-70 max-w-sm mx-auto" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif", color: "#1E2761" }}>
            Tap notifikasi sebelum jatuh ke percakapan. Jangan sampai lolos!
          </p>
        </div>

        <div className="max-w-sm mx-auto">
          {/* Game area */}
          <div
            className="neo-card overflow-hidden relative"
            style={{ height: 420, background: "linear-gradient(180deg, #4D96FF 0%, #E8D5FF 60%, #FFF8F0 100%)" }}
          >
            {/* HUD */}
            {phase === "playing" && (
              <div className="absolute top-3 left-3 right-3 flex justify-between z-20">
                <div
                  className="px-3 py-1.5 rounded-full neo-border-2 font-display font-800 text-sm"
                  style={{ fontFamily: "'Baloo 2', cursive", background: "#FFD93D", color: "#1E2761", borderColor: "#1E2761" }}
                >
                  {score} pts
                </div>
                <div
                  className="px-3 py-1.5 rounded-full neo-border-2 font-display font-800 text-sm"
                  style={{
                    fontFamily: "'Baloo 2', cursive",
                    background: timeLeft <= 5 ? "#FF6B6B" : "#FFF8F0",
                    color: "#1E2761",
                    borderColor: "#1E2761",
                  }}
                >
                  {timeLeft}s
                </div>
              </div>
            )}

            {/* Bubbles */}
            {phase === "playing" &&
              bubbles.map((b) => (
                <button
                  key={b.id}
                  className="absolute neo-border-2 rounded-full w-12 h-12 flex items-center justify-center text-xl cursor-pointer transition-transform hover:scale-110 active:scale-90 z-10"
                  style={{
                    left: `${b.x}%`,
                    top: `${b.y}%`,
                    background: b.color,
                    borderColor: "#1E2761",
                    transform: "translateX(-50%)",
                  }}
                  onClick={() => catchBubble(b.id)}
                >
                  {b.emoji}
                </button>
              ))}

            {/* Bottom — people talking */}
            <div className="absolute bottom-0 left-0 right-0 h-24 flex items-center justify-center gap-6 px-4">
              <div
                className="w-14 h-14 rounded-full neo-border flex items-center justify-center text-2xl"
                style={{ background: "#FFB4A2", borderColor: "#1E2761" }}
              >
                😊
              </div>
              <div
                className="flex-1 max-w-24 h-8 rounded-2xl neo-border-2 flex items-center justify-center text-xs font-700"
                style={{
                  background: "#ffffff",
                  borderColor: "#1E2761",
                  fontFamily: "'Plus Jakarta Sans', sans-serif",
                  color: "#1E2761",
                }}
              >
                ngobrol...
              </div>
              <div
                className="w-14 h-14 rounded-full neo-border flex items-center justify-center text-2xl"
                style={{ background: "#6BCB77", borderColor: "#1E2761" }}
              >
                🙂
              </div>
            </div>

            {/* Idle overlay */}
            {phase === "idle" && (
              <div className="absolute inset-0 flex flex-col items-center justify-center gap-4 bg-navy/80 z-30" style={{ background: "rgba(30,39,97,0.85)" }}>
                <div className="text-4xl">🎮</div>
                <p className="font-display font-800 text-xl text-center px-4" style={{ fontFamily: "'Baloo 2', cursive", color: "#FFF8F0" }}>
                  Blok semua notifikasi!
                </p>
                <button className="btn-neo btn-coral" onClick={startGame}>
                  ▶ Mulai Game
                </button>
              </div>
            )}

            {/* Result overlay */}
            {phase === "result" && (
              <div className="absolute inset-0 flex flex-col items-center justify-center gap-4 z-30" style={{ background: "rgba(30,39,97,0.9)" }}>
                <div className="text-4xl">{score >= 100 ? "🏆" : "💪"}</div>
                <div className="font-display font-800 text-3xl" style={{ fontFamily: "'Baloo 2', cursive", color: "#FFD93D" }}>
                  {score} pts
                </div>
                <div className="font-700 text-base" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif", color: "#FFF8F0" }}>
                  {rating}
                </div>
                <div className="text-xs opacity-60" style={{ color: "rgba(255,255,255,0.6)", fontFamily: "'Plus Jakarta Sans', sans-serif" }}>
                  {missed} notifikasi lolos
                </div>
                <button className="btn-neo btn-mint" onClick={startGame}>
                  🔄 Main Lagi
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    </section>
  );
}
