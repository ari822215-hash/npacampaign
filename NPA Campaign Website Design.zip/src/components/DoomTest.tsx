import { useState, useEffect, useRef } from "react";
import Nopi from "./Nopi";

const fakePosts = [
  { user: "@si_tika", content: "Reminder bahwa kamu belum produktif hari ini 🙃", likes: "4.2K", color: "#FF6B6B", avatar: "🧑‍🦱" },
  { user: "@daily_doom", content: "7 hal yang akan menghancurkan hidupmu — no. 4 paling mengejutkan", likes: "12K", color: "#FFD93D", avatar: "😱" },
  { user: "@health_bro", content: "Kamu makan itu tadi? Baca ini dulu sebelum menyesal", likes: "8.7K", color: "#4D96FF", avatar: "💪" },
  { user: "@aesthetic.life", content: "POV: hidupmu masih jauh dari yang kamu inginkan", likes: "31K", color: "#C4B5FD", avatar: "✨" },
  { user: "@news_panic", content: "BREAKING: situasi semakin memburuk dan kamu tidak tahu apa-apa", likes: "67K", color: "#6BCB77", avatar: "📰" },
  { user: "@compare.core", content: "Teman lamamu baru aja beli mobil. Gimana denganmu?", likes: "2.1K", color: "#FFB4A2", avatar: "😮" },
  { user: "@anxiety_feed", content: "Kalau kamu masih single di usia ini... thread 🧵", likes: "44K", color: "#FF6B6B", avatar: "💔" },
  { user: "@hustle.always", content: "Orang sukses ga punya waktu istirahat. Kalau kamu istirahat, kamu kalah.", likes: "19K", color: "#FFD93D", avatar: "🔥" },
];

type Phase = "idle" | "scrolling" | "result";

const results = [
  { min: 0, max: 5, label: "Kamu cukup kebal doom.", desc: "Skill langka banget sekarang ini. Nopi respect 🫡", nopiPose: "win" as const },
  { min: 5, max: 12, label: "Doomscroller pemula.", desc: "Kamu sadar, tapi tetep ketarik. Wajar — algoritmanya memang dirancang untuk itu.", nopiPose: "crossed" as const },
  { min: 12, max: 25, label: "Udah level menengah.", desc: "HP kamu tahu lebih banyak soal ketakutanmu daripada kamu sendiri. Mau break?", nopiPose: "sticker1" as const },
  { min: 25, max: 999, label: "Doomscroller sejati 💀", desc: "Kamu bahkan tidak sadar kapan mulainya. Ini saatnya NPA.", nopiPose: "drop" as const },
];

export default function DoomTest() {
  const [phase, setPhase] = useState<Phase>("idle");
  const [seconds, setSeconds] = useState(0);
  const [scrollY, setScrollY] = useState(0);
  const feedRef = useRef<HTMLDivElement>(null);
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const start = () => {
    setPhase("scrolling");
    setSeconds(0);
    setScrollY(0);
    timerRef.current = setInterval(() => {
      setSeconds((s) => s + 1);
    }, 1000);
  };

  const stop = () => {
    if (timerRef.current) clearInterval(timerRef.current);
    setPhase("result");
  };

  const reset = () => {
    if (timerRef.current) clearInterval(timerRef.current);
    setPhase("idle");
    setSeconds(0);
    setScrollY(0);
  };

  useEffect(() => {
    return () => { if (timerRef.current) clearInterval(timerRef.current); };
  }, []);

  // Auto-scroll feed in scrolling phase
  useEffect(() => {
    if (phase !== "scrolling") return;
    const interval = setInterval(() => {
      setScrollY((y) => y + 1.2);
      if (feedRef.current) {
        feedRef.current.scrollTop = scrollY;
      }
    }, 16);
    return () => clearInterval(interval);
  }, [phase, scrollY]);

  const result = results.find((r) => seconds >= r.min && seconds < r.max) || results[results.length - 1];

  return (
    <section id="doomtest" className="section-pad" style={{ background: "#FFF8F0" }}>
      <div className="max-w-[1080px] mx-auto px-6">
        <div className="text-center mb-10">
          <span className="kicker block mb-3">Doomscrolling Test</span>
          <h2
            className="font-display font-800 mb-3"
            style={{ fontFamily: "'Baloo 2', cursive", fontWeight: 800, fontSize: "clamp(26px, 4vw, 38px)", color: "#1E2761", lineHeight: 1.2 }}
          >
            Seberapa lama kamu tahan?
          </h2>
          <p className="text-sm opacity-70 max-w-md mx-auto" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif", color: "#1E2761" }}>
            Scroll feed palsu ini. Hentikan saat kamu sadar kamu lagi doomscrolling.
          </p>
        </div>

        <div className="max-w-sm mx-auto">
          {/* Phone frame */}
          <div
            className="neo-card overflow-hidden"
            style={{ background: "#1E2761" }}
          >
            {/* Phone header */}
            <div className="flex items-center justify-between px-4 py-3 border-b-2 border-navy" style={{ borderColor: "rgba(255,255,255,0.15)" }}>
              <div className="flex gap-1.5">
                <div className="w-2 h-2 rounded-full" style={{ background: "#FF6B6B" }} />
                <div className="w-2 h-2 rounded-full" style={{ background: "#FFD93D" }} />
                <div className="w-2 h-2 rounded-full" style={{ background: "#6BCB77" }} />
              </div>
              <span
                className="font-700 text-xs"
                style={{ fontFamily: "'Plus Jakarta Sans', sans-serif", color: "rgba(255,255,255,0.7)", fontWeight: 700 }}
              >
                FeedApp™
              </span>
              {phase === "scrolling" && (
                <span
                  className="font-display font-800 text-sm animate-pulse-glow"
                  style={{ fontFamily: "'Baloo 2', cursive", color: "#FF6B6B" }}
                >
                  {seconds}s
                </span>
              )}
              {phase !== "scrolling" && <div className="w-12" />}
            </div>

            {/* Feed */}
            {phase !== "result" && (
              <div
                ref={feedRef}
                className="overflow-hidden"
                style={{ height: 380, overflowY: phase === "scrolling" ? "hidden" : "auto" }}
              >
                {(phase === "idle" ? fakePosts.slice(0, 3) : [...fakePosts, ...fakePosts]).map((post, i) => (
                  <div
                    key={`${i}-${post.user}`}
                    className="border-b-2 px-4 py-4"
                    style={{ borderColor: "rgba(255,255,255,0.08)", background: i % 2 === 0 ? "rgba(255,255,255,0.04)" : "transparent" }}
                  >
                    <div className="flex items-start gap-3">
                      <div
                        className="w-9 h-9 rounded-full flex items-center justify-center text-base flex-shrink-0 neo-border-2"
                        style={{ background: post.color, borderColor: "rgba(255,255,255,0.3)" }}
                      >
                        {post.avatar}
                      </div>
                      <div className="flex-1">
                        <div className="text-xs font-700 mb-1" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif", color: post.color, fontWeight: 700 }}>
                          {post.user}
                        </div>
                        <p className="text-sm leading-snug mb-2" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif", color: "rgba(255,255,255,0.85)" }}>
                          {post.content}
                        </p>
                        <div className="flex items-center gap-3 text-xs opacity-50" style={{ color: "rgba(255,255,255,0.5)" }}>
                          <span>❤️ {post.likes}</span>
                          <span>💬</span>
                          <span>🔁</span>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}

                {phase === "idle" && (
                  <div className="flex items-center justify-center h-16 opacity-40">
                    <span className="text-xs" style={{ color: "rgba(255,255,255,0.5)" }}>start untuk mulai scroll...</span>
                  </div>
                )}
              </div>
            )}

            {/* Result in phone */}
            {phase === "result" && (
              <div className="p-6 flex flex-col items-center gap-4 text-center" style={{ minHeight: 380 }}>
                <Nopi pose={result.nopiPose} size={90} />
                <div>
                  <div
                    className="font-display font-800 text-xl mb-1"
                    style={{ fontFamily: "'Baloo 2', cursive", fontWeight: 800, color: "#FFD93D" }}
                  >
                    {seconds} detik
                  </div>
                  <div
                    className="font-700 text-base mb-2"
                    style={{ fontFamily: "'Plus Jakarta Sans', sans-serif", color: "#FFF8F0", fontWeight: 700 }}
                  >
                    {result.label}
                  </div>
                  <p className="text-sm opacity-70" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif", color: "#FFF8F0" }}>
                    {result.desc}
                  </p>
                </div>
                <button className="btn-neo btn-mint text-sm py-2 px-5" onClick={reset}>
                  🔄 Coba lagi
                </button>
              </div>
            )}

            {/* CTA bar */}
            <div className="p-4 border-t-2" style={{ borderColor: "rgba(255,255,255,0.1)" }}>
              {phase === "idle" && (
                <button className="btn-neo btn-coral w-full justify-center" onClick={start}>
                  ▶ Mulai Scroll
                </button>
              )}
              {phase === "scrolling" && (
                <button className="btn-neo btn-yellow w-full justify-center" onClick={stop}>
                  ✋ Stop! Aku sadar
                </button>
              )}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
