export default function BoardGame() {
  return (
    <section style={{ background: "#FFD93D", borderTop: "3px solid #1E2761", borderBottom: "3px solid #1E2761" }}>
      <div className="max-w-[1080px] mx-auto px-6 py-8 flex flex-col md:flex-row items-center justify-between gap-6">
        <div className="flex items-center gap-5">
          <div className="text-5xl animate-bounce-sm">🎲</div>
          <div>
            <div
              className="text-xs font-800 tracking-wider uppercase mb-1"
              style={{ fontFamily: "'Plus Jakarta Sans', sans-serif", fontWeight: 800, color: "#1E2761", opacity: 0.6, letterSpacing: "0.1em" }}
            >
              COMING SOON
            </div>
            <h3
              className="font-display font-800 text-2xl md:text-3xl"
              style={{ fontFamily: "'Baloo 2', cursive", fontWeight: 800, color: "#1E2761" }}
            >
              NPA: The Board Game
            </h3>
            <p
              className="text-sm font-600 opacity-70"
              style={{ fontFamily: "'Plus Jakarta Sans', sans-serif", color: "#1E2761" }}
            >
              Versi offline dari gerakan ini. Dimainkan IRL, bersama orang-orang nyata.
            </p>
          </div>
        </div>
        <div
          className="px-5 py-2.5 neo-border rounded-full font-700 text-sm cursor-not-allowed opacity-60"
          style={{
            fontFamily: "'Plus Jakarta Sans', sans-serif",
            fontWeight: 700,
            background: "rgba(255,255,255,0.5)",
            borderColor: "#1E2761",
            color: "#1E2761",
          }}
        >
          Notify me 🔔
        </div>
      </div>
    </section>
  );
}
