import { useState, useRef } from "react";
import Nopi from "./Nopi";

const challenges = [
  {
    id: "1d",
    label: "1 Hari",
    title: "NPA 24 Jam",
    desc: "Satu hari penuh — taruh HP saat kamu sama orang-orang yang kamu sayangi.",
    gradient: "linear-gradient(135deg, #4D96FF, #2DD4BF)",
    bg: "#4D96FF",
    nopiLine: "Satu hari aja dulu. Kamu bisa.",
    emoji: "🌱",
    tagline: "Put the phone down. Pick the moment up.",
  },
  {
    id: "3d",
    label: "3 Hari",
    title: "NPA Weekend",
    desc: "Tiga hari challenge — mulai dari momen makan, jalan, dan ngobrol.",
    gradient: "linear-gradient(135deg, #FF6B6B, #FFD93D)",
    bg: "#FF6B6B",
    nopiLine: "Tiga hari cukup untuk mulai ngerasain bedanya.",
    emoji: "🌿",
    tagline: "Less Screen, More Connection.",
  },
  {
    id: "7d",
    label: "7 Hari",
    title: "NPA Week",
    desc: "Tujuh hari penuh — bangun habit baru dan rasakan perbedaan kualitas hidupmu.",
    gradient: "linear-gradient(135deg, #6BCB77, #4D96FF)",
    bg: "#6BCB77",
    nopiLine: "Satu minggu. Selamanya berubah.",
    emoji: "🌳",
    tagline: "Hadir sepenuhnya adalah bentuk kasih sayang.",
  },
];

export default function Challenge() {
  const [selected, setSelected] = useState<string | null>(null);
  const [name, setName] = useState("");
  const [pledged, setPledged] = useState(false);
  const pledgeRef = useRef<HTMLDivElement>(null);

  const active = challenges.find((c) => c.id === selected);

  const handleSelect = (id: string) => {
    setSelected(id);
    setPledged(false);
    setTimeout(() => {
      pledgeRef.current?.scrollIntoView({ behavior: "smooth", block: "center" });
    }, 200);
  };

  const today = new Date().toLocaleDateString("id-ID", { day: "numeric", month: "long", year: "numeric" });

  return (
    <section id="challenge" className="section-pad" style={{ background: "#FFF8F0" }}>
      <div className="max-w-[1080px] mx-auto px-6">
        {/* Header */}
        <div className="text-center mb-10">
          <span className="kicker block mb-3">NPA Challenge</span>
          <h2
            className="font-display font-800 mb-3"
            style={{ fontFamily: "'Baloo 2', cursive", fontWeight: 800, fontSize: "clamp(26px, 4vw, 38px)", color: "#1E2761", lineHeight: 1.2 }}
          >
            Pilih durasi challengemu.
          </h2>
          <p className="text-sm opacity-70" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif", color: "#1E2761" }}>
            Tidak ada yang terlalu kecil. Satu hari pun udah dimulai.
          </p>
        </div>

        {/* Options */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-5 mb-10">
          {challenges.map((c) => {
            const isActive = selected === c.id;
            return (
              <button
                key={c.id}
                className="text-left neo-card p-6 transition-all duration-200 cursor-pointer"
                style={{
                  background: isActive ? c.bg : "#ffffff",
                  boxShadow: isActive ? `7px 7px 0 rgba(30,39,97,0.22)` : "5px 5px 0 rgba(30,39,97,0.14)",
                  transform: isActive ? "translate(-2px, -2px)" : "none",
                }}
                onClick={() => handleSelect(c.id)}
              >
                <div
                  className="text-3xl mb-3"
                  style={{ filter: isActive ? "none" : "grayscale(0.3)" }}
                >
                  {c.emoji}
                </div>
                <div
                  className="font-display font-800 text-2xl mb-1"
                  style={{ fontFamily: "'Baloo 2', cursive", fontWeight: 800, color: "#1E2761" }}
                >
                  {c.label}
                </div>
                <div
                  className="font-700 text-base mb-2"
                  style={{ fontFamily: "'Plus Jakarta Sans', sans-serif", fontWeight: 700, color: "#1E2761" }}
                >
                  {c.title}
                </div>
                <p
                  className="text-sm opacity-70"
                  style={{ fontFamily: "'Plus Jakarta Sans', sans-serif", color: "#1E2761" }}
                >
                  {c.desc}
                </p>

                {isActive && (
                  <div className="mt-4 flex items-center gap-2 animate-slide-up">
                    <Nopi pose="point" size={48} />
                    <p
                      className="text-xs font-700 italic"
                      style={{ fontFamily: "'Plus Jakarta Sans', sans-serif", color: "#1E2761", fontWeight: 700 }}
                    >
                      "{c.nopiLine}"
                    </p>
                  </div>
                )}
              </button>
            );
          })}
        </div>

        {/* Pledge Card */}
        {active && (
          <div ref={pledgeRef} className="max-w-md mx-auto animate-slide-up">
            {!pledged ? (
              <div className="neo-card p-6" style={{ background: "#FFF8F0" }}>
                <h3
                  className="font-display font-800 text-xl mb-4 text-center"
                  style={{ fontFamily: "'Baloo 2', cursive", fontWeight: 800, color: "#1E2761" }}
                >
                  Siapa namamu?
                </h3>
                <p className="text-sm opacity-60 text-center mb-5" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif", color: "#1E2761" }}>
                  Opsional — buat pledge card-mu lebih personal.
                </p>
                <input
                  className="input-neo mb-4"
                  placeholder="Nama kamu (opsional)"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                />
                <button
                  className="btn-neo btn-coral w-full justify-center text-base py-3"
                  onClick={() => setPledged(true)}
                >
                  ✊ Buat Pledge Card
                </button>
              </div>
            ) : (
              <PledgeCard challenge={active} name={name} date={today} />
            )}
          </div>
        )}
      </div>
    </section>
  );
}

function PledgeCard({ challenge, name, date }: { challenge: (typeof challenges)[0]; name: string; date: string }) {
  return (
    <div>
      {/* Card */}
      <div
        className="neo-card p-7 text-center mb-4 relative overflow-hidden"
        style={{ background: challenge.gradient }}
        id="pledge-card-export"
      >
        {/* Decoration circles */}
        <div className="absolute -top-8 -right-8 w-24 h-24 rounded-full opacity-20" style={{ background: "#1E2761" }} />
        <div className="absolute -bottom-6 -left-6 w-20 h-20 rounded-full opacity-15" style={{ background: "#ffffff" }} />

        <div
          className="inline-block px-3 py-1 text-xs font-800 rounded-full neo-border-2 mb-4"
          style={{ fontFamily: "'Plus Jakarta Sans', sans-serif", fontWeight: 800, background: "rgba(255,255,255,0.7)", borderColor: "#1E2761", color: "#1E2761" }}
        >
          NPA PLEDGE CARD
        </div>

        <div className="text-4xl mb-2">{challenge.emoji}</div>

        <div
          className="font-display font-800 text-3xl mb-1"
          style={{ fontFamily: "'Baloo 2', cursive", fontWeight: 800, color: "#1E2761" }}
        >
          {challenge.title}
        </div>

        {name && (
          <div
            className="font-700 text-lg mb-2"
            style={{ fontFamily: "'Plus Jakarta Sans', sans-serif", fontWeight: 700, color: "rgba(30,39,97,0.8)" }}
          >
            oleh {name}
          </div>
        )}

        <div className="text-xs font-600 opacity-60 mb-4" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif", color: "#1E2761" }}>
          Dimulai {date}
        </div>

        <div
          className="font-700 text-sm italic"
          style={{ fontFamily: "'Plus Jakarta Sans', sans-serif", fontWeight: 700, color: "#1E2761" }}
        >
          "{challenge.tagline}"
        </div>

        <div className="mt-4 flex justify-center">
          <Nopi pose="win" size={70} />
        </div>
      </div>

      {/* Actions */}
      <div className="flex gap-3">
        <button
          className="btn-neo btn-navy flex-1 justify-center text-sm py-2.5"
          onClick={() => alert("Download pledge card (implementasi screenshot API)")}
        >
          ⬇ Download
        </button>
        <button
          className="btn-neo btn-yellow flex-1 justify-center text-sm py-2.5"
          onClick={() => {
            if (navigator.share) {
              navigator.share({ title: "NPA Pledge", text: `Aku mulai NPA ${challenge.title}! ${challenge.tagline}` });
            } else {
              navigator.clipboard.writeText(`Aku mulai NPA ${challenge.title}! ${challenge.tagline} #NPAChallenge`);
              alert("Link disalin!");
            }
          }}
        >
          ↗ Share
        </button>
      </div>
    </div>
  );
}
