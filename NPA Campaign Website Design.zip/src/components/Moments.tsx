const moments = [
  {
    icon: "👁️",
    title: "Kontak mata yang bertahan",
    desc: "Bukan yang cepat dialihkan ke layar. Yang beneran — yang terasa, yang diingat.",
    bg: "#4D96FF",
    quote: "Ada momen di mana kamu tau seseorang beneran lihat kamu.",
  },
  {
    icon: "😂",
    title: "Tawa yang meledak bareng",
    desc: "Bukan LOL di chat. Tawa yang bikin perut sakit dan mata berkaca — yang cuma bisa terjadi saat kamu beneran di situ.",
    bg: "#FFD93D",
    quote: "Momen terbaik ga punya loading screen.",
  },
  {
    icon: "🤫",
    title: "Diam yang nyaman",
    desc: "Saat kamu sama seseorang dan ga perlu bilang apa-apa. HP justru akan mengisi ruang yang baiknya dibiarkan.",
    bg: "#6BCB77",
    quote: "Kehadiran penuh bisa bersuara tanpa kata.",
  },
];

export default function Moments() {
  return (
    <section className="section-pad" style={{ background: "#FFF8F0" }}>
      <div className="max-w-[1080px] mx-auto px-6">
        <div className="text-center mb-10">
          <span className="kicker block mb-3">Moments</span>
          <h2
            className="font-display font-800 mb-3"
            style={{ fontFamily: "'Baloo 2', cursive", fontWeight: 800, fontSize: "clamp(26px, 4vw, 38px)", color: "#1E2761", lineHeight: 1.2 }}
          >
            Yang ga bisa di-screenshot.
          </h2>
          <p className="text-sm opacity-70" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif", color: "#1E2761" }}>
            Ini yang hilang kalau kamu terus pegang HP.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
          {moments.map((m, i) => (
            <div
              key={i}
              className="neo-card p-6 flex flex-col gap-4 hover:-translate-y-1.5 transition-transform duration-200"
              style={{ background: m.bg }}
            >
              <div className="text-4xl">{m.icon}</div>
              <h3
                className="font-display font-800 text-xl"
                style={{ fontFamily: "'Baloo 2', cursive", fontWeight: 800, color: "#1E2761" }}
              >
                {m.title}
              </h3>
              <p
                className="text-sm leading-relaxed flex-1"
                style={{ fontFamily: "'Plus Jakarta Sans', sans-serif", color: "#1E2761", opacity: 0.8 }}
              >
                {m.desc}
              </p>
              <blockquote
                className="text-xs font-700 italic border-l-4 pl-3"
                style={{
                  fontFamily: "'Plus Jakarta Sans', sans-serif",
                  color: "#1E2761",
                  borderColor: "#1E2761",
                  opacity: 0.7,
                }}
              >
                "{m.quote}"
              </blockquote>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
