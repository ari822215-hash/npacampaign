import { useState, useEffect } from "react";

export default function Nav() {
  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);

  useEffect(() => {
    const handler = () => setScrolled(window.scrollY > 30);
    window.addEventListener("scroll", handler);
    return () => window.removeEventListener("scroll", handler);
  }, []);

  const links = [
    { label: "Kenapa NPA", href: "#edukasi" },
    { label: "Tes", href: "#doomtest" },
    { label: "Challenge", href: "#challenge" },
    { label: "Game", href: "#game" },
    { label: "Tim", href: "#tim" },
  ];

  return (
    <nav
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 nav-blur border-b-[3px] border-navy ${
        scrolled ? "shadow-sm" : ""
      }`}
      style={{ borderColor: "#1E2761" }}
    >
      <div className="max-w-[1080px] mx-auto px-6 h-16 flex items-center justify-between">
        {/* Logo */}
        <a href="#" className="flex items-center gap-2 group">
          <div
            className="w-10 h-10 rounded-full flex items-center justify-center font-display font-800 text-lg text-cream neo-border"
            style={{ background: "#1E2761", color: "#FFF8F0", fontFamily: "'Baloo 2', cursive", fontWeight: 800, borderColor: "#1E2761" }}
          >
            N
          </div>
          <span
            className="font-display font-800 text-xl"
            style={{ fontFamily: "'Baloo 2', cursive", fontWeight: 800, color: "#1E2761" }}
          >
            NPA
            <span
              className="inline-block w-2 h-2 rounded-full ml-0.5 mb-1 align-middle"
              style={{ background: "#6BCB77", border: "2px solid #1E2761", display: "inline-block" }}
            />
          </span>
        </a>

        {/* Desktop links */}
        <ul className="hidden md:flex items-center gap-6">
          {links.map((l) => (
            <li key={l.href}>
              <a
                href={l.href}
                className="font-body text-sm font-700 transition-colors hover:text-sky"
                style={{ fontFamily: "'Plus Jakarta Sans', sans-serif", fontWeight: 700, color: "#1E2761" }}
              >
                {l.label}
              </a>
            </li>
          ))}
        </ul>

        {/* CTA */}
        <a
          href="#challenge"
          className="hidden md:flex btn-neo btn-coral text-sm py-2 px-5"
          style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}
        >
          Mulai NPA
        </a>

        {/* Mobile hamburger */}
        <button
          className="md:hidden w-10 h-10 flex flex-col items-center justify-center gap-1.5 neo-border rounded-xl"
          style={{ borderColor: "#1E2761", background: "#FFF8F0" }}
          onClick={() => setMenuOpen(!menuOpen)}
          aria-label="Toggle menu"
        >
          <span className="w-5 h-0.5 bg-navy block" style={{ background: "#1E2761" }} />
          <span className="w-5 h-0.5 bg-navy block" style={{ background: "#1E2761" }} />
          <span className="w-3 h-0.5 bg-navy block self-start ml-1" style={{ background: "#1E2761" }} />
        </button>
      </div>

      {/* Mobile menu */}
      {menuOpen && (
        <div className="md:hidden border-t-[3px] border-navy px-6 py-4 flex flex-col gap-4" style={{ borderColor: "#1E2761", background: "rgba(255,248,240,0.97)" }}>
          {links.map((l) => (
            <a
              key={l.href}
              href={l.href}
              className="font-700 text-base text-navy"
              style={{ fontWeight: 700, color: "#1E2761" }}
              onClick={() => setMenuOpen(false)}
            >
              {l.label}
            </a>
          ))}
          <a href="#challenge" className="btn-neo btn-coral self-start text-sm" onClick={() => setMenuOpen(false)}>
            Mulai NPA
          </a>
        </div>
      )}
    </nav>
  );
}
