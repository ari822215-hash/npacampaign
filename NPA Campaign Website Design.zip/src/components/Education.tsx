import { useState } from "react";

// 5a: Compare — 1 Jam Scroll vs 1 Jam Ngobrol
function CompareSection() {
  const [mode, setMode] = useState<"scroll" | "ngobrol">("scroll");

  const scrollContent = {
    title: "1 Jam Scroll",
    subtitle: "yang kamu dapatkan:",
    items: ["237 konten dikonsumsi", "0 percakapan bermakna", "Rasa lelah tanpa alasan jelas", "Perbandingan diri tanpa henti", "Doomscrolling tanpa sadar"],
    chars: ["😶‍🌫️", "😑", "😮‍💨"],
    color: "#4D96FF",
    bg: "#E8D5FF",
  };

  const ngobolContent = {
    title: "1 Jam Ngobrol",
    subtitle: "yang kamu dapatkan:",
    items: ["Tawa yang meledak bareng", "Pemahaman yang lebih dalam", "Rasa didengar & dimengerti", "Kenangan yang bertahan", "Koneksi yang nyata"],
    chars: ["😄", "🤝", "✨"],
    color: "#6BCB77",
    bg: "#6BCB77",
  };

  const content = mode === "scroll" ? scrollContent : ngobolContent;

  return (
    <div className="neo-card p-6 md:p-8" style={{ background: "#FFF8F0" }}>
      <div className="flex items-center gap-3 mb-6 flex-wrap">
        <span className="kicker">Perbandingan</span>
        <div className="toggle-pill ml-auto">
          <button
            className={`toggle-option ${mode === "scroll" ? "active" : ""}`}
            onClick={() => setMode("scroll")}
          >
            📱 Scroll
          </button>
          <button
            className={`toggle-option ${mode === "ngobrol" ? "active" : ""}`}
            onClick={() => setMode("ngobrol")}
          >
            💬 Ngobrol
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-center">
        {/* Characters */}
        <div className="flex justify-center gap-4">
          {content.chars.map((c, i) => (
            <div
              key={`${mode}-${i}`}
              className="w-16 h-16 rounded-full neo-border flex items-center justify-center text-2xl transition-all duration-500 animate-slide-up"
              style={{
                background: content.bg,
                borderColor: "#1E2761",
                animationDelay: `${i * 80}ms`,
                filter: mode === "scroll" ? "grayscale(0.4)" : "none",
              }}
            >
              {c}
            </div>
          ))}
        </div>

        {/* Content */}
        <div key={mode} className="animate-slide-up">
          <h3
            className="font-display font-800 text-2xl mb-1"
            style={{ fontFamily: "'Baloo 2', cursive", fontWeight: 800, color: "#1E2761" }}
          >
            {content.title}
          </h3>
          <p className="text-sm font-600 mb-3 opacity-60" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif", color: "#1E2761" }}>
            {content.subtitle}
          </p>
          <ul className="flex flex-col gap-2">
            {content.items.map((item, i) => (
              <li key={i} className="flex items-center gap-2 text-sm font-600" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif", color: "#1E2761" }}>
                <span
                  className="w-2 h-2 rounded-full flex-shrink-0"
                  style={{ background: content.color }}
                />
                {item}
              </li>
            ))}
          </ul>
        </div>
      </div>
    </div>
  );
}

// 5b: Attention Span — Brain with exploding tabs
function BrainSection() {
  const [exploded, setExploded] = useState(false);

  const tabs = ["Reels", "Chat", "Notif", "Feed", "Story", "Shop"];

  return (
    <div className="neo-card p-6 md:p-8" style={{ background: "#FFF8F0" }}>
      <span className="kicker block mb-3">Attention Span</span>
      <h3
        className="font-display font-800 text-2xl mb-2"
        style={{ fontFamily: "'Baloo 2', cursive", fontWeight: 800, color: "#1E2761" }}
      >
        Otakmu lagi overload.
      </h3>
      <p className="text-sm mb-6 opacity-70" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif", color: "#1E2761" }}>
        Setiap notifikasi merobek fokusmu. Hover / tap untuk lihat bedanya.
      </p>

      <div
        className="relative flex items-center justify-center cursor-pointer"
        style={{ height: 180 }}
        onMouseEnter={() => setExploded(true)}
        onMouseLeave={() => setExploded(false)}
        onClick={() => setExploded(!exploded)}
      >
        {/* Brain */}
        <div
          className="relative z-10 w-20 h-20 rounded-full neo-border flex items-center justify-center text-4xl transition-all duration-300"
          style={{
            background: exploded ? "#FF6B6B" : "#6BCB77",
            transform: exploded ? "scale(0.85)" : "scale(1)",
            borderColor: "#1E2761",
          }}
        >
          🧠
        </div>

        {/* Exploding tabs */}
        {tabs.map((tab, i) => {
          const angle = (i / tabs.length) * 360;
          const rad = (angle * Math.PI) / 180;
          const r = exploded ? 80 : 0;
          const x = Math.cos(rad) * r;
          const y = Math.sin(rad) * r;

          return (
            <div
              key={tab}
              className="absolute z-20 px-2 py-1 text-xs font-700 neo-border rounded-full transition-all duration-400"
              style={{
                fontFamily: "'Plus Jakarta Sans', sans-serif",
                fontWeight: 700,
                background: ["#FFD93D", "#FF6B6B", "#4D96FF", "#6BCB77", "#C4B5FD", "#FFB4A2"][i],
                borderColor: "#1E2761",
                transform: `translate(${x}px, ${y}px)`,
                opacity: exploded ? 1 : 0,
                transitionDelay: `${i * 40}ms`,
                color: "#1E2761",
              }}
            >
              {tab}
            </div>
          );
        })}

        {!exploded && (
          <div className="absolute bottom-2 text-xs font-600 opacity-50" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif", color: "#1E2761" }}>
            hover untuk lihat dampaknya
          </div>
        )}
        {exploded && (
          <div className="absolute bottom-2 text-xs font-700 text-coral" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif", color: "#FF6B6B" }}>
            ini yang terjadi setiap hari di kepalamu 😵
          </div>
        )}
      </div>
    </div>
  );
}

// 5c: Empathy — connection lines
function EmpathySection() {
  const [phoneVisible, setPhoneVisible] = useState(false);

  return (
    <div className="neo-card p-6 md:p-8" style={{ background: "#FFF8F0" }}>
      <span className="kicker block mb-3">Empati</span>
      <h3
        className="font-display font-800 text-2xl mb-2"
        style={{ fontFamily: "'Baloo 2', cursive", fontWeight: 800, color: "#1E2761" }}
      >
        Koneksi yang diam-diam putus.
      </h3>
      <p className="text-sm mb-5 opacity-70" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif", color: "#1E2761" }}>
        Satu HP di meja bisa memutus koneksi emosional — bahkan tanpa disentuh.
      </p>

      {/* Scene */}
      <div className="relative flex items-center justify-center gap-12 mb-5" style={{ height: 120 }}>
        {/* Person A */}
        <div className="flex flex-col items-center gap-2">
          <div className="w-14 h-14 rounded-full neo-border flex items-center justify-center text-2xl" style={{ background: "#4D96FF", borderColor: "#1E2761" }}>😊</div>
          <span className="text-xs font-700" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif", color: "#1E2761" }}>Kamu</span>
        </div>

        {/* Connection line */}
        <div className="absolute left-1/2 -translate-x-1/2 top-5 w-28">
          <div
            className="relative h-1 rounded-full transition-all duration-500"
            style={{
              background: phoneVisible ? "#FF6B6B" : "#6BCB77",
              opacity: phoneVisible ? 0.4 : 1,
            }}
          />
          {phoneVisible && (
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-8 h-12 rounded neo-border flex items-center justify-center text-sm animate-slide-up"
              style={{ background: "#1E2761", borderColor: "#1E2761" }}>
              <span style={{ fontSize: 16 }}>📱</span>
            </div>
          )}
        </div>

        {/* Person B */}
        <div className="flex flex-col items-center gap-2">
          <div
            className="w-14 h-14 rounded-full neo-border flex items-center justify-center text-2xl transition-all"
            style={{
              background: "#FFB4A2",
              borderColor: "#1E2761",
              filter: phoneVisible ? "grayscale(0.5)" : "none",
            }}
          >
            {phoneVisible ? "😶" : "😄"}
          </div>
          <span className="text-xs font-700" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif", color: "#1E2761" }}>Dia</span>
        </div>
      </div>

      <div className="flex gap-3">
        <button
          className={`btn-neo text-sm py-2 px-4 flex-1 ${phoneVisible ? "btn-coral" : "btn-navy"}`}
          onClick={() => setPhoneVisible(true)}
        >
          📱 Munculin HP
        </button>
        <button
          className="btn-neo btn-mint text-sm py-2 px-4 flex-1"
          onClick={() => setPhoneVisible(false)}
        >
          👀 Balikin Fokus
        </button>
      </div>
    </div>
  );
}

// 5d: Kualitas Momen
function MomentQualitySection() {
  const [value, setValue] = useState(20);
  const [started, setStarted] = useState(false);

  const start = () => {
    if (started) return;
    setStarted(true);
    let v = 20;
    const interval = setInterval(() => {
      v += 2;
      setValue(v);
      if (v >= 88) clearInterval(interval);
    }, 50);
  };

  const labels = [
    { pct: 0, label: "Semua pegang HP" },
    { pct: 40, label: "Mulai taruh HP" },
    { pct: 70, label: "Lebih fokus" },
    { pct: 88, label: "Hadir sepenuhnya ✨" },
  ];

  const current = labels.reduce((acc, l) => (value >= l.pct ? l : acc), labels[0]);

  return (
    <div className="neo-card p-6 md:p-8" style={{ background: "#FFF8F0" }}>
      <span className="kicker block mb-3">Kualitas Momen</span>
      <h3
        className="font-display font-800 text-2xl mb-2"
        style={{ fontFamily: "'Baloo 2', cursive", fontWeight: 800, color: "#1E2761" }}
      >
        Dari 20% ke 88%.
      </h3>
      <p className="text-sm mb-5 opacity-70" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif", color: "#1E2761" }}>
        Kualitas momen saat semua taruh HP vs pas semua pegang HP.
      </p>

      {/* Progress */}
      <div className="mb-4">
        <div className="flex justify-between text-xs font-700 mb-2" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif", color: "#1E2761" }}>
          <span>{value}%</span>
          <span style={{ color: "#6BCB77" }}>{current.label}</span>
        </div>
        <div className="h-5 rounded-full neo-border overflow-hidden" style={{ borderColor: "#1E2761" }}>
          <div className="progress-bar-fill h-full rounded-full" style={{ width: `${value}%` }} />
        </div>
      </div>

      {/* Stage indicators */}
      <div className="flex gap-2 mb-5 flex-wrap">
        {labels.map((l, i) => (
          <div
            key={i}
            className="text-xs px-2 py-1 rounded-full font-600 transition-all"
            style={{
              fontFamily: "'Plus Jakarta Sans', sans-serif",
              background: value >= l.pct ? "#6BCB77" : "rgba(30,39,97,0.08)",
              color: "#1E2761",
              border: "2px solid",
              borderColor: value >= l.pct ? "#1E2761" : "transparent",
              fontWeight: 600,
            }}
          >
            {l.label}
          </div>
        ))}
      </div>

      <button
        className="btn-neo btn-yellow text-sm py-2 px-5"
        onClick={started ? () => { setValue(20); setStarted(false); } : start}
      >
        {started && value >= 88 ? "🔄 Ulang" : started ? "sedang berjalan..." : "▶ Mulai simulasi"}
      </button>
    </div>
  );
}

export default function Education() {
  return (
    <section id="edukasi" className="section-pad" style={{ background: "#FFF8F0" }}>
      <div className="max-w-[1080px] mx-auto px-6">
        {/* Header */}
        <div className="text-center mb-12">
          <span className="kicker block mb-3">Kenapa NPA?</span>
          <h2
            className="font-display font-800 mb-4"
            style={{ fontFamily: "'Baloo 2', cursive", fontWeight: 800, fontSize: "clamp(28px, 4vw, 42px)", color: "#1E2761", lineHeight: 1.15 }}
          >
            4 hal yang pelan-pelan hilang<br className="hidden md:block" /> tanpa kita sadar
          </h2>
          <p
            className="text-base opacity-70 max-w-lg mx-auto"
            style={{ fontFamily: "'Plus Jakarta Sans', sans-serif", color: "#1E2761" }}
          >
            Bukan soal anti-teknologi. Soal hadir di momen yang benar-benar penting.
          </p>
        </div>

        {/* 2x2 Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          <CompareSection />
          <BrainSection />
          <EmpathySection />
          <MomentQualitySection />
        </div>
      </div>
    </section>
  );
}
