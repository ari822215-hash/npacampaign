import { useState, useEffect } from "react";
import Nopi from "./Nopi";

// Six characters at a table, all hunched over phones (Before state)
function TableScene({ showAfter }: { showAfter: boolean }) {
  const colors = ["#FF6B6B", "#FFD93D", "#6BCB77", "#4D96FF", "#C4B5FD", "#FFB4A2"];
  const names = ["A", "B", "C", "D", "E", "F"];

  return (
    <div className="relative w-full max-w-[560px] mx-auto" style={{ height: 220 }}>
      {/* Table */}
      <div
        className="absolute left-1/2 -translate-x-1/2"
        style={{
          top: 90,
          width: 440,
          height: 60,
          background: showAfter ? "#FFD93D" : "#2a3580",
          border: "3px solid #1E2761",
          borderRadius: 16,
          boxShadow: "5px 5px 0 rgba(30,39,97,0.2)",
          transition: "background 0.8s ease",
        }}
      />

      {/* Characters around table */}
      {colors.map((color, i) => {
        const topRow = i < 3;
        const x = topRow
          ? [60, 220, 380][i]
          : [60, 220, 380][i - 3];
        const y = topRow ? 10 : 130;

        return (
          <div
            key={i}
            className="absolute transition-all duration-700"
            style={{ left: x, top: y, transform: "translateX(-50%)" }}
          >
            <CharacterHead
              color={color}
              label={names[i]}
              hunched={!showAfter}
              showAfter={showAfter}
              delay={i * 100}
            />
          </div>
        );
      })}

      {/* Floating notifications (before state) */}
      {!showAfter && (
        <div className="absolute inset-0 pointer-events-none">
          {[
            { emoji: "❤️", x: 80, y: 20, anim: "animate-float1" },
            { emoji: "💬", x: 200, y: 5, anim: "animate-float2" },
            { emoji: "🔔", x: 340, y: 15, anim: "animate-float3" },
            { emoji: "👍", x: 450, y: 25, anim: "animate-float1" },
            { emoji: "📲", x: 130, y: 35, anim: "animate-float2" },
          ].map((n, i) => (
            <div
              key={i}
              className={`absolute text-xl ${n.anim}`}
              style={{ left: n.x, top: n.y, fontSize: 20 }}
            >
              {n.emoji}
            </div>
          ))}
        </div>
      )}

      {/* After: connection lines */}
      {showAfter && (
        <svg
          className="absolute inset-0 pointer-events-none"
          width="100%"
          height="100%"
          style={{ opacity: 0.5 }}
        >
          <line x1="60" y1="50" x2="220" y2="50" stroke="#6BCB77" strokeWidth="2" strokeDasharray="6,3"/>
          <line x1="220" y1="50" x2="380" y2="50" stroke="#6BCB77" strokeWidth="2" strokeDasharray="6,3"/>
          <line x1="60" y1="165" x2="220" y2="165" stroke="#6BCB77" strokeWidth="2" strokeDasharray="6,3"/>
          <line x1="220" y1="165" x2="380" y2="165" stroke="#6BCB77" strokeWidth="2" strokeDasharray="6,3"/>
        </svg>
      )}
    </div>
  );
}

function CharacterHead({
  color,
  label,
  hunched,
  showAfter,
  delay,
}: {
  color: string;
  label: string;
  hunched: boolean;
  showAfter: boolean;
  delay: number;
}) {
  return (
    <div
      className="flex flex-col items-center gap-1 transition-all duration-500"
      style={{
        transform: hunched ? "rotate(25deg) translateY(6px)" : "rotate(0deg) translateY(0px)",
        transitionDelay: `${delay}ms`,
      }}
    >
      {/* Head */}
      <div
        className="w-10 h-10 rounded-full flex items-center justify-center font-display font-800 text-sm neo-border"
        style={{
          background: color,
          borderColor: "#1E2761",
          fontFamily: "'Baloo 2', cursive",
          fontWeight: 800,
          color: "#1E2761",
          filter: hunched ? "grayscale(0.3)" : "none",
          transition: "filter 0.8s ease",
        }}
      >
        {showAfter ? "😊" : label}
      </div>
      {/* Phone (disappears in after) */}
      <div
        className="transition-all duration-500"
        style={{
          opacity: hunched ? 1 : 0,
          transform: hunched ? "scale(1)" : "scale(0) rotate(45deg)",
          transitionDelay: `${delay}ms`,
        }}
      >
        <div
          className="w-5 h-7 rounded neo-border-2 flex items-center justify-center"
          style={{ background: "#1E2761", borderColor: "#1E2761" }}
        >
          <div className="w-3 h-4 rounded-sm" style={{ background: "#4D96FF", opacity: 0.7 }} />
        </div>
      </div>
    </div>
  );
}

export default function Hero() {
  const [showAfter, setShowAfter] = useState(false);
  const [hasToggled, setHasToggled] = useState(false);

  const handleDrop = () => {
    setShowAfter(true);
    setHasToggled(true);
  };

  const handleReset = () => {
    setShowAfter(false);
  };

  return (
    <section
      className="relative min-h-screen flex flex-col justify-center overflow-hidden transition-colors duration-1000"
      style={{
        background: showAfter
          ? "linear-gradient(160deg, #FFF8F0 0%, #FFB4A2 40%, #6BCB77 100%)"
          : "linear-gradient(160deg, #1E2761 0%, #2a3580 50%, #0f1540 100%)",
        paddingTop: 80,
      }}
    >
      {/* Before: abstract bg shapes */}
      {!showAfter && (
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <div className="absolute top-20 -right-20 w-80 h-80 rounded-full opacity-10" style={{ background: "#4D96FF" }} />
          <div className="absolute bottom-20 -left-20 w-60 h-60 rounded-full opacity-10" style={{ background: "#C4B5FD" }} />
        </div>
      )}

      <div className="max-w-[1080px] mx-auto px-6 w-full py-16">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          {/* Text block */}
          <div className="order-2 lg:order-1">
            {/* Tag */}
            <div
              className="inline-block mb-6 animate-tag"
              style={{ transform: "rotate(-3deg)" }}
            >
              <span
                className="px-4 py-2 text-sm font-800 neo-border"
                style={{
                  fontFamily: "'Plus Jakarta Sans', sans-serif",
                  fontWeight: 800,
                  background: "#FFD93D",
                  borderColor: "#1E2761",
                  borderRadius: 8,
                  color: "#1E2761",
                  display: "block",
                }}
              >
                No Phone Around
              </span>
            </div>

            {/* H1 */}
            {!showAfter ? (
              <h1
                className="font-display mb-4 leading-tight"
                style={{
                  fontFamily: "'Baloo 2', cursive",
                  fontWeight: 800,
                  fontSize: "clamp(36px, 5vw, 54px)",
                  color: "#ffffff",
                  lineHeight: 1.08,
                }}
              >
                Semua{" "}
                <span style={{ color: "#FFD93D" }}>"hadir"</span>,
                <br />
                ga ada yang beneran ada.
              </h1>
            ) : (
              <h1
                className="font-display mb-4 leading-tight animate-slide-up"
                style={{
                  fontFamily: "'Baloo 2', cursive",
                  fontWeight: 800,
                  fontSize: "clamp(36px, 5vw, 54px)",
                  color: "#1E2761",
                  lineHeight: 1.08,
                }}
              >
                Less Screen,{" "}
                <span className="gradient-text">More Connection.</span>
              </h1>
            )}

            {/* Sub */}
            {!showAfter ? (
              <p
                className="mb-8 text-base md:text-lg leading-relaxed"
                style={{
                  fontFamily: "'Plus Jakarta Sans', sans-serif",
                  color: "rgba(255,255,255,0.75)",
                  maxWidth: 460,
                }}
              >
                6 orang, 1 meja, 0 kontak mata.{" "}
                <span style={{ color: "#FFB4A2" }}>Familiar?</span>
              </p>
            ) : (
              <p
                className="mb-8 text-base md:text-lg leading-relaxed animate-slide-up"
                style={{
                  fontFamily: "'Plus Jakarta Sans', sans-serif",
                  color: "#1E2761",
                  opacity: 0.8,
                  maxWidth: 460,
                  animationDelay: "0.1s",
                }}
              >
                Karena momen terbaik ga butuh notifikasi.
              </p>
            )}

            {/* CTA */}
            <div className="flex flex-wrap gap-3 items-center">
              {!showAfter ? (
                <button
                  className="btn-neo btn-coral text-base px-8 py-3"
                  onClick={handleDrop}
                >
                  📵 DROP THE PHONE
                </button>
              ) : (
                <>
                  <a href="#challenge" className="btn-neo btn-yellow text-base px-8 py-3 animate-slide-up">
                    ✨ Mulai NPA Experience
                  </a>
                  <button
                    className="btn-neo btn-outline text-sm px-4 py-2.5"
                    onClick={handleReset}
                    style={{ color: "#1E2761" }}
                  >
                    ← lihat lagi
                  </button>
                </>
              )}
            </div>

            {/* Tagline */}
            {!showAfter && (
              <p
                className="mt-6 text-sm font-600 italic"
                style={{ color: "rgba(255,255,255,0.5)", fontFamily: "'Plus Jakarta Sans', sans-serif" }}
              >
                "Put the phone down. Pick the moment up."
              </p>
            )}
          </div>

          {/* Scene */}
          <div className="order-1 lg:order-2 flex flex-col items-center gap-6">
            <TableScene showAfter={showAfter} />

            {/* Nopi appears in after state */}
            {showAfter && (
              <div className="animate-slide-up flex flex-col items-center gap-2">
                <Nopi pose="win" size={100} />
                <div
                  className="px-3 py-1.5 text-xs font-700 rounded-full neo-border-2"
                  style={{ background: "#6BCB77", color: "#1E2761", fontFamily: "'Plus Jakarta Sans', sans-serif", fontWeight: 700, borderColor: "#1E2761" }}
                >
                  ya gitu dong! 🎉
                </div>
              </div>
            )}

            {!showAfter && !hasToggled && (
              <div
                className="text-xs font-600 animate-bounce-sm"
                style={{ color: "rgba(255,255,255,0.5)", fontFamily: "'Plus Jakarta Sans', sans-serif" }}
              >
                ↑ klik DROP THE PHONE untuk lihat perbedaannya
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Bottom wave */}
      <div className="absolute bottom-0 left-0 right-0 h-16 overflow-hidden pointer-events-none">
        <svg viewBox="0 0 1440 64" fill="none" preserveAspectRatio="none" style={{ width: "100%", height: "100%" }}>
          <path
            d="M0,32 C360,64 720,0 1080,32 C1260,48 1380,40 1440,32 L1440,64 L0,64 Z"
            fill={showAfter ? "#FFF8F0" : "#FFF8F0"}
            opacity="0.9"
          />
        </svg>
      </div>
    </section>
  );
}
