import { useState } from "react";

type Beat = "start" | "choice" | "ending";

const story = {
  start: {
    text: "Kamu lagi makan malam sama teman lama. Pertama kali ketemu setelah 6 bulan. Dia lagi cerita sesuatu yang penting.",
    choices: [
      { label: "📱 Cek HP sebentar — ada notif masuk", next: "check" },
      { label: "👀 Fokus ke dia, HP di saku", next: "focus" },
    ],
  },
  check: {
    text: "Kamu buka HP — ternyata cuma promo belanja. Pas ngangkat muka, dia udah ganti topik. Senyumnya sedikit berbeda.",
    choices: [
      { label: "🔄 Coba ulang dari awal", next: "restart" },
      { label: "💬 Minta dia cerita lagi", next: "apologize" },
    ],
  },
  focus: {
    text: "Kamu taruh HP face-down. Dia ngelihat itu dan senyum. Ceritanya terus mengalir — dan kamu dapet momen yang ga akan terlupakan.",
    choices: [
      { label: "✨ Lihat endingnya", next: "good_ending" },
      { label: "🔄 Coba path lain", next: "restart" },
    ],
  },
  apologize: {
    text: "Kamu minta maaf dan bilang fokus sekarang. Dia ngangguk, tapi energinya udah beda. Momen itu ga bisa di-rewind.",
    choices: [
      { label: "🔄 Coba lagi dari awal", next: "restart" },
    ],
  },
  good_ending: {
    text: "Dua jam berlalu tanpa sadar. HP tetap di saku. Waktu pulang, dia bilang: 'Makasih udah beneran hadir malam ini.' Kamu baru sadar betapa jarangnya itu.",
    choices: [
      { label: "🏠 Selesai — kembali ke atas", next: "done" },
      { label: "🔄 Baca lagi", next: "restart" },
    ],
  },
};

type StoryKey = keyof typeof story;

export default function Storytelling() {
  const [current, setCurrent] = useState<StoryKey>("start");
  const [history, setHistory] = useState<string[]>([]);

  const handleChoice = (next: string) => {
    if (next === "restart") {
      setCurrent("start");
      setHistory([]);
    } else if (next === "done") {
      window.scrollTo({ top: 0, behavior: "smooth" });
    } else {
      setHistory([...history, current]);
      setCurrent(next as StoryKey);
    }
  };

  const scene = story[current];

  const pathColor = current === "good_ending"
    ? "#6BCB77"
    : current === "check" || current === "apologize"
    ? "#FF6B6B"
    : "#FFD93D";

  return (
    <section className="section-pad" style={{ background: "#1E2761" }}>
      <div className="max-w-[1080px] mx-auto px-6">
        <div className="text-center mb-10">
          <span className="kicker block mb-3" style={{ color: "#FFD93D" }}>Storytelling</span>
          <h2
            className="font-display font-800 mb-3"
            style={{ fontFamily: "'Baloo 2', cursive", fontWeight: 800, fontSize: "clamp(26px, 4vw, 38px)", color: "#FFF8F0", lineHeight: 1.2 }}
          >
            Pilih jalanmu.
          </h2>
        </div>

        <div className="max-w-lg mx-auto">
          {/* Progress breadcrumbs */}
          {history.length > 0 && (
            <div className="flex items-center gap-2 mb-4 flex-wrap">
              {history.map((h, i) => (
                <span
                  key={i}
                  className="text-xs px-2 py-1 rounded-full font-600"
                  style={{
                    background: "rgba(255,255,255,0.1)",
                    color: "rgba(255,255,255,0.5)",
                    fontFamily: "'Plus Jakarta Sans', sans-serif",
                    fontWeight: 600,
                  }}
                >
                  {h}
                </span>
              ))}
              <span className="text-xs opacity-30" style={{ color: "rgba(255,255,255,0.5)" }}>→</span>
              <span
                className="text-xs px-2 py-1 rounded-full font-700"
                style={{ background: pathColor, color: "#1E2761", fontFamily: "'Plus Jakarta Sans', sans-serif", fontWeight: 700 }}
              >
                {current}
              </span>
            </div>
          )}

          {/* Story box */}
          <div
            className="neo-card p-7 mb-6 transition-all duration-300"
            style={{ background: pathColor, borderColor: "#1E2761" }}
            key={current}
          >
            <p
              className="font-700 text-base md:text-lg leading-relaxed"
              style={{ fontFamily: "'Plus Jakarta Sans', sans-serif", fontWeight: 700, color: "#1E2761" }}
            >
              {scene.text}
            </p>
          </div>

          {/* Choices */}
          <div className="flex flex-col gap-3">
            {scene.choices.map((c, i) => (
              <button
                key={i}
                className="btn-neo text-left text-sm py-3 px-5 w-full"
                style={{
                  background: i === 0 ? "#FFF8F0" : "rgba(255,255,255,0.15)",
                  color: i === 0 ? "#1E2761" : "#FFF8F0",
                  borderColor: i === 0 ? "#1E2761" : "rgba(255,255,255,0.4)",
                  justifyContent: "flex-start",
                }}
                onClick={() => handleChoice(c.next)}
              >
                {c.label}
              </button>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
