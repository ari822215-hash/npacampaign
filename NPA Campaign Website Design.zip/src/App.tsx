import Nav from "./components/Nav";
import QuoteStrip from "./components/QuoteStrip";
import Hero from "./components/Hero";
import Stats from "./components/Stats";
import Education from "./components/Education";
import Tips from "./components/Tips";
import Myths from "./components/Myths";
import Data from "./components/Data";
import DoomTest from "./components/DoomTest";
import Challenge from "./components/Challenge";
import Storytelling from "./components/Storytelling";
import MiniGame from "./components/MiniGame";
import DetoxTimer from "./components/DetoxTimer";
import Moments from "./components/Moments";
import BoardGame from "./components/BoardGame";
import Team from "./components/Team";
import Footer from "./components/Footer";

export default function App() {
  return (
    <div className="min-h-screen" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>
      <Nav />

      {/* 01 Quote Strip Top */}
      <div style={{ paddingTop: 64 }}>
        <QuoteStrip position="top" />
      </div>

      {/* 02–03 Hero */}
      <Hero />

      {/* 04 Stats Bar */}
      <Stats />

      {/* 05 Education */}
      <Education />

      {/* 06 Tips */}
      <Tips />

      {/* 07 Myths (Flip) */}
      <Myths />

      {/* 08 Data */}
      <Data />

      {/* 09 Doomscrolling Test */}
      <DoomTest />

      {/* 10 Challenge + Pledge */}
      <Challenge />

      {/* 11 Storytelling */}
      <Storytelling />

      {/* 12 Mini Game */}
      <MiniGame />

      {/* 13 Detox Timer */}
      <DetoxTimer />

      {/* 14 Moments */}
      <Moments />

      {/* 15 Board Game Teaser */}
      <BoardGame />

      {/* 16 Team */}
      <Team />

      {/* 17 Quote Strip Bottom */}
      <QuoteStrip position="bottom" />

      {/* 18 Footer */}
      <Footer />
    </div>
  );
}
